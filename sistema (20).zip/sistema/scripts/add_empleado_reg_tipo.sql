-- Script para agregar columna que identifica el tipo de usuario que registró al cliente
-- Ejecutar este script en phpMyAdmin o MySQL

USE sistema;

-- Agregar columna para identificar el tipo: 'admin', 'empleado', 'cliente', o NULL (auto-registro)
ALTER TABLE `clientes` 
ADD COLUMN `registrado_por_tipo` VARCHAR(20) DEFAULT NULL COMMENT 'Tipo: admin, empleado, cliente, o NULL si auto-registro' AFTER `empleado_reg_id`;

-- Actualizar registros existentes basándose en la tabla usuarios
UPDATE `clientes` c
INNER JOIN `usuarios` u ON c.empleado_reg_id = u.id
SET c.registrado_por_tipo = CASE 
    WHEN u.rol_id = 1 THEN 'admin'
    WHEN u.rol_id = 2 THEN 'empleado'
    ELSE 'staff'
END
WHERE c.empleado_reg_id > 0;

-- Actualizar registros que no están en usuarios pero sí en empleados
UPDATE `clientes` c
INNER JOIN `empleados` e ON c.empleado_reg_id = e.id
SET c.registrado_por_tipo = 'empleado'
WHERE c.empleado_reg_id > 0 AND c.registrado_por_tipo IS NULL;

-- Verificar los cambios
SELECT id, nombre, empleado_reg_id, registrado_por_tipo, fecha_registro FROM clientes ORDER BY id DESC;
