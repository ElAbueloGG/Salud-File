<?php
// Script para crear entradas en `usuarios` desde filas de `empleados`.
// Uso: php create_users_from_empleados.php run  O visitar en el navegador con ?run=1
require __DIR__ . '/../includes/db.php';

echo "Previsualización empleados -> usuarios:\n";
$res = mysqli_query($conn, "SELECT id,nombre, user, password, telefono FROM empleados");
$to_create = [];
while($r = mysqli_fetch_assoc($res)){
    $emp_id = $r['id'];
    $nombre = $r['nombre'];
    $user = trim($r['user']);
    $pass = $r['password'];
    // generate email if user not provided
    if(!$user){
        $user_safe = preg_replace('/[^a-z0-9]/i','',strtolower(str_replace(' ','',$nombre)));
        $email = $user_safe . '@example.local';
    } else {
        $email = $user;
    }
    // check exists
    $esc = mysqli_real_escape_string($conn,$email);
    $check = mysqli_query($conn, "SELECT id FROM usuarios WHERE email='$esc' LIMIT 1");
    if(mysqli_num_rows($check) > 0) continue;
    $to_create[] = ['nombre'=>$nombre,'email'=>$email,'password'=>$pass];
}

if(empty($to_create)){
    echo "No se encontraron empleados nuevos para migrar.\n";
    exit;
}

echo "A crear: " . count($to_create) . " usuarios\n";
foreach($to_create as $t){
    echo "- " . $t['nombre'] . " -> " . $t['email'] . "\n";
}

$run = (isset($argv) && isset($argv[1]) && $argv[1] === 'run') || (isset($_GET['run']) && $_GET['run']==1);
if(!$run){
    echo "\nPrevisualización. Para aplicar ejecutar: php create_users_from_empleados.php run o visitar ?run=1\n";
    exit;
}

foreach($to_create as $t){
    $nombre = mysqli_real_escape_string($conn,$t['nombre']);
    $email = mysqli_real_escape_string($conn,$t['email']);
    $password = mysqli_real_escape_string($conn,$t['password']);
    // create with rol_id = 2 (Empleado)
    $sql = "INSERT INTO usuarios (nombre,email,password,rol_id) VALUES ('$nombre','$email','$password',2)";
    if(mysqli_query($conn,$sql)){
        echo "Usuario creado: $email\n";
    } else {
        echo "Error al crear $email : " . mysqli_error($conn) . "\n";
    }
}

echo "Hecho.\n";
