<?php
// Script para agregar columnas a la tabla `clientes`:
// created_by INT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
// status TINYINT(1) DEFAULT 1, deactivated_by INT NULL, deactivated_at DATETIME NULL
// además agrega UNIQUE(email)
require __DIR__ . '/../includes/db.php';

echo "Previsualización migración clientes schema:\n";

$preview = [];

$cols = [];
$r = mysqli_query($conn, "SHOW COLUMNS FROM clientes");
while($c = mysqli_fetch_assoc($r)) $cols[] = $c['Field'];

if(!in_array('created_by',$cols)) $preview[] = "ALTER TABLE clientes ADD COLUMN created_by INT NULL";
if(!in_array('created_at',$cols)) $preview[] = "ALTER TABLE clientes ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP";
if(!in_array('status',$cols)) $preview[] = "ALTER TABLE clientes ADD COLUMN status TINYINT(1) NOT NULL DEFAULT 1";
if(!in_array('deactivated_by',$cols)) $preview[] = "ALTER TABLE clientes ADD COLUMN deactivated_by INT NULL";
if(!in_array('deactivated_at',$cols)) $preview[] = "ALTER TABLE clientes ADD COLUMN deactivated_at DATETIME NULL";

// check unique email
$has_unique_email = false;
$r = mysqli_query($conn, "SHOW INDEX FROM clientes");
while($c = mysqli_fetch_assoc($r)){
    if($c['Key_name'] === 'email') $has_unique_email = true;
}
if(!$has_unique_email) $preview[] = "ALTER TABLE clientes ADD UNIQUE KEY (email)";

if(empty($preview)){
    echo "No hay cambios necesarios en la tabla clientes.\n";
    exit;
}

foreach($preview as $p) echo "- $p\n";

$run = (isset($argv) && isset($argv[1]) && $argv[1] === 'run') || (isset($_GET['run']) && $_GET['run']==1);
if(!$run){
    echo "\nModo previsualización. Para aplicar ejecutar: php migrate_clientes_schema.php run o visitar ?run=1\n";
    exit;
}

foreach($preview as $p){
    echo "Ejecutando: $p ... ";
    if(mysqli_query($conn,$p)) echo "OK\n"; else echo "ERROR: " . mysqli_error($conn) . "\n";
}

echo "Migración completada.\n";
