<?php
// Script de migración para mover datos desde 'descripcion' a 'referencia' y 'motivo'
// Uso: visitar desde navegador o ejecutar en línea de comandos
// Para ejecutar la migración real añade ?run=1 a la URL o ejecuta: php migrate_pagos.php run

require __DIR__ . '/../includes/db.php';

echo "Migración pagos: mover datos de 'descripcion' -> 'referencia' + 'motivo'\n";

// Mostrar preview
$res = mysqli_query($conn, "SELECT id, descripcion, referencia, motivo FROM pagos LIMIT 1000");
$to_update = [];
while($r = mysqli_fetch_assoc($res)){
    $id = $r['id'];
    $desc = $r['descripcion'];
    $ref = $r['referencia'];
    $mot = $r['motivo'];
    if((empty($ref) || is_null($ref)) && !empty($desc)){
        // intentar parsear formato "Ref: <valor> | <motivo>"
        if(preg_match('/^\s*Ref:\s*([^|]+)\s*\|\s*(.*)$/i', $desc, $m)){
            $new_ref = trim($m[1]);
            $new_mot = trim($m[2]);
        } else {
            // si no coincide, guardar todo en motivo
            $new_ref = '';
            $new_mot = $desc;
        }
        $to_update[] = ['id'=>$id,'ref'=>$new_ref,'mot'=>$new_mot];
    }
}

if(empty($to_update)){
    echo "No se encontraron filas a migrar.\n";
} else {
    echo "Filas a migrar: " . count($to_update) . "\n";
    foreach($to_update as $u){
        echo "ID={$u['id']} -> referencia='" . ($u['ref']?:'<empty>') . "' motivo='" . substr($u['mot'],0,80) . "'\n";
    }

    $run = isset($argv) && isset($argv[1]) && $argv[1] === 'run';
    $run = $run || (isset($_GET['run']) && $_GET['run'] == '1');

    if(!$run){
        echo "\nPrevisualización lista. Para aplicar la migración añade '?run=1' a la URL o ejecuta 'php migrate_pagos.php run' desde línea de comandos.\n";
        exit;
    }

    // Ejecutar updates
    foreach($to_update as $u){
        $id = (int)$u['id'];
        $ref = mysqli_real_escape_string($conn, $u['ref']);
        $mot = mysqli_real_escape_string($conn, $u['mot']);
        $sql = "UPDATE pagos SET referencia='".$ref."', motivo='".$mot."' WHERE id=$id";
        mysqli_query($conn, $sql);
    }

    echo "Migración aplicada.\n";

    // Opción: eliminar columna descripcion si existe
    $cols = [];
    $rcols = mysqli_query($conn, "SHOW COLUMNS FROM pagos");
    while($c = mysqli_fetch_assoc($rcols)){
        $cols[] = $c['Field'];
    }
    if(in_array('descripcion', $cols)){
        echo "La columna 'descripcion' existe. Se eliminará.\n";
        $sql = "ALTER TABLE pagos DROP COLUMN descripcion";
        mysqli_query($conn, $sql);
        echo "Columna 'descripcion' eliminada.\n";
    } else {
        echo "Columna 'descripcion' no existe.\n";
    }
}

echo "Fin.\n";
