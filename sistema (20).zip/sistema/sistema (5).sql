-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-11-2025 a las 02:59:56
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(120) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `empleado_reg_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deactivated_at` datetime DEFAULT NULL,
  `deactivated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `telefono`, `direccion`, `email`, `password`, `fecha_registro`, `empleado_reg_id`, `status`, `deactivated_at`, `deactivated_by`) VALUES
(1, 'Abel Espin', '7341146318', 'tehuixtla morelos', 'abel@gmail.com', '123', '2025-11-22 18:21:33', 0, 1, NULL, NULL),
(2, 'Juan Perez', '7341146318', 'Jojutla', 'juancho@gmail.com', '', '2025-11-22 18:21:55', 0, 1, NULL, NULL),
(3, 'Abel Espin', '7341146318', '12312412', 'admin1@example.com', '123456', '2025-11-22 19:44:42', 0, 1, NULL, NULL),
(4, 'Roberto Campos', '7341146318', 'joju', 'roberto@example.com', '12345678', '2025-11-22 21:37:07', 0, 1, NULL, NULL),
(5, 'jose rodriguez', '3544123412', 'zacatepec\r\n', 'jose@gmail.com', '634134123', '2025-11-22 21:37:33', 0, 1, NULL, NULL),
(6, 'Juaquin Espin ', '5657245235', 'cuerna', 'Juaquines@example.com', '123246', '2025-11-22 21:38:03', 0, 1, NULL, NULL),
(7, 'Anel Espin', '7341146318', 'tilza\r\n', 'Juaquinesds@example.com', '235251123', '2025-11-22 21:38:32', 0, 1, NULL, NULL),
(8, 'Rafael T', '251351532214', 'galeana\\r\\n', 'rafa@example.com', '12345678', '2025-11-22 21:59:14', 0, 1, NULL, NULL),
(9, 'jose chuy', '8128381', 'assaddasd', 'josechuy@gmail.com', '', '2025-11-23 21:48:01', 1, 1, NULL, NULL),
(10, 'lalogarza', '1431234124', 'asdasd', 'lalogarza@example.com', '123456', '2025-11-23 21:49:40', 1, 1, NULL, NULL),
(11, 'alav sada', '7341146318', '121eqwe', 'alav@example.com', '121241241', '2025-11-23 21:52:20', 1, 1, NULL, NULL),
(12, 'jjCampos', '7341141234', 'adda', 'jj@gmail.com', '', '2025-11-23 21:57:24', 2, 1, NULL, NULL),
(13, 'Rafael Tasdasd', '2131513511', 'sdfadf', 'awrasfda@example.com', '63312423423', '2025-11-23 21:57:54', 1, 1, NULL, NULL),
(14, '3wedfasfa', '7341141234', 'asdsa', 'jrjertwre@example.com', '123456', '2025-11-23 22:00:07', 1, 1, NULL, NULL),
(15, 'lkjasklasdkl', '7341146318', 'sdfsddsf', 'jhjgdsffsdv@gmail.com', '24525432', '2025-11-23 22:00:18', 1, 1, NULL, NULL),
(16, 'dfhfdsdsfas', '7341146318', 'gqwefqf', 'dgkafpamsd@example.com', '', '2025-11-23 22:02:53', 1, 1, NULL, NULL),
(17, 'Roberto Campos', '7341146318', '23123', 'roberto@gmail.com', '', '2025-11-23 22:28:33', 2, 1, NULL, NULL),
(18, 'Roberto Campos', '7341146318', 'sad', 'robertsdadao@gmail.com', '', '2025-11-23 22:28:45', 2, 1, NULL, NULL),
(19, 'Juan Perezasas', '7341146318', 'asfasd', 'asdas6723413d@gmail.com', '', '2025-11-23 22:30:18', 2, 1, NULL, NULL),
(20, 'jklasdlkas', '62423423', 'asdasdad', 'gagdsvvc@gmail.com', '', '2025-11-23 22:30:58', 5, 0, '2025-11-23 19:38:56', 1),
(21, 'lkjnsdflnkjsdfv', '091234890', 'SDASFASFAS', 'nokjiasDFKLJ@example.com', '|123454', '2025-11-23 22:31:24', 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos`
--

CREATE TABLE `documentos` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `archivo` varchar(255) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `documentos`
--

INSERT INTO `documentos` (`id`, `cliente_id`, `tipo`, `archivo`, `fecha`) VALUES
(18, 5, 'INE', '1763918867_logo.jpeg', '2025-11-23 17:27:47'),
(22, 2, 'Acta de nacimiento', '1763918911_logo.jpeg', '2025-11-23 17:28:31'),
(23, 1, 'Receta', '1763920417_logo.jpeg', '2025-11-23 17:53:37'),
(24, 1, 'Acta de nacimiento', '1763920423_Sistema (3).pdf', '2025-11-23 17:53:43'),
(25, 1, 'CURP', '1763920429_Sistema.pdf', '2025-11-23 17:53:49'),
(26, 1, 'INE', '1763920435_logo.jpeg', '2025-11-23 17:53:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `puesto` varchar(60) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deactivated_at` datetime DEFAULT NULL,
  `deactivated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id`, `nombre`, `puesto`, `telefono`, `email`, `password`, `fecha_registro`, `status`, `deactivated_at`, `deactivated_by`) VALUES
(2, 'Julio Rodriguez', 'Sub-Director', '7341231234', 'julio@gmail.com', '123', '2025-11-22 18:31:18', 1, NULL, NULL),
(3, 'Abel Espin', 'asada', '2312341241241', 'ab@example.com', '1234', '2025-11-23 17:29:04', 1, NULL, NULL),
(4, 'Rafael T', 'Sub-Director', '7341141234', 'sadad@gmail.com', '12345678', '2025-11-23 17:29:19', 1, NULL, NULL),
(5, 'Juan', 'Director', '7341141234', 'gsdfsaa@example.com', '1234', '2025-11-23 17:29:31', 1, NULL, NULL),
(6, 'Roberto Rodriguez', 'Director', '7341141234', 'gadasd@example.com', '1234', '2025-11-23 17:29:47', 1, NULL, NULL),
(7, 'Benja', 'Director', '7341146318', 'bbb@example.com', '1234', '2025-11-23 17:30:10', 1, NULL, NULL),
(8, 'Vector', 'Sub-Director', '7341141234', 'vvvv@example.com', '1234', '2025-11-23 17:30:26', 1, NULL, NULL),
(9, 'Juan Julio', 'asada', '7341141234', 'affasfassfadmin@example.com', '1234', '2025-11-23 17:30:40', 1, NULL, NULL),
(10, 'Roberto Campos', 'Sub-Director', '7341141234', 'dfsfa@example.com', '1234', '2025-11-23 17:30:49', 0, '2025-11-23 16:03:38', 1),
(11, 'JulianCampos', 'Director', '7341146318', 'gfdssdfgfdsaad@example.com', '1234', '2025-11-23 17:31:01', 1, NULL, NULL),
(12, 'Juan Eduardo', 'intendente', '809128012031', 'juancho1234@example.com', '123456', '2025-11-23 21:30:58', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `referencia` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `comprobante` varchar(255) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id`, `cliente_id`, `monto`, `referencia`, `descripcion`, `comprobante`, `fecha`) VALUES
(16, 5, 2600.00, '12313', 'ss', '1763848875_Sistema.pdf', '2025-11-22 22:01:15'),
(17, 6, 2600.00, '12313', '13412', '1763848889_Sistema (2).pdf', '2025-11-22 22:01:29'),
(18, 4, 2600.00, '12313', 'ss', '1763848898_Sistema.pdf', '2025-11-22 22:01:38'),
(19, 8, 2000.00, 'ase', '13412', '1763848909_Sistema (2).pdf', '2025-11-22 22:01:49'),
(20, 4, 2600.00, '12313', 'ss', '1763848918_Sistema (2).pdf', '2025-11-22 22:01:58'),
(21, 3, 2600.00, 'ss', '13412', '1763848931_menu.pdf', '2025-11-22 22:02:11'),
(22, 7, 2600.00, '12313', '13412', '1763849065_Sistema (1).pdf', '2025-11-22 22:04:25'),
(23, 4, 2000.00, 'ss', '13412', '1763849074_menu.pdf', '2025-11-22 22:04:34'),
(24, 2, 2000.00, '12313', 'ss', '1763849089_Sistema (1).pdf', '2025-11-22 22:04:49'),
(25, 1, 2000.00, '12313', 'ss', '1763849099_menu.pdf', '2025-11-22 22:04:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre`) VALUES
(1, 'Admin'),
(2, 'Empleado'),
(3, 'Cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `rol_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `telefono`, `email`, `password`, `rol_id`) VALUES
(1, 'Empresario', '134151123', 'admin@example.com', '123456', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `rol_id` (`rol_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `documentos`
--
ALTER TABLE `documentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD CONSTRAINT `documentos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
