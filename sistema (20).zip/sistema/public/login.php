<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="card-title mb-3">Iniciar sesión</h4>
                <form id="loginForm">
                    <div class="mb-3">
                        <label for="email" class="form-label">Correo</label>
                        <input type="text" class="form-control" name="email" id="email" placeholder="email@dominio.com">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Contraseña">
                    </div>
                    <div class="d-grid">
                        <button class="btn btn-primary" type="submit">Entrar</button>
                    </div>
                </form>
                <div id="respuesta" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
$('#loginForm').on('submit', function(e){
    e.preventDefault();
    let datos = new FormData(this);
    fetch('login_ajax.php', { method: 'POST', body: datos })
        .then(r => r.text())
        .then(t => {
            t = t.trim();
            if(t.startsWith('OK')){
                const parts = t.split(':');
                const role = (parts[1] || '').trim();
                if(role === 'admin' || role === 'empleado' || role === 'staff') {
                    window.location.href = 'dashboard.php';
                } else if(role === 'cliente') {
                    window.location.href = 'client_documentos.php';
                } else {
                    window.location.href = 'dashboard.php';
                }
            } else {
                if(t.trim() === 'Cuenta desactivada'){
                    Swal.fire({icon:'error', title:'Cuenta desactivada', text:'Tu cuenta ha sido desactivada. Contacta al administrador si crees que es un error.'});
                } else {
                    Swal.fire({icon:'error', title:'Error', text: t});
                }
            }
        })
        .catch(err => Swal.fire({icon:'error', title:'Error', text: 'Error de red'}));
});
</script>
