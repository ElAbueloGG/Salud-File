<?php
session_start();
if(!isset($_SESSION['cliente_id'])){
    echo "Acceso denegado";
    exit;
}

require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/functions.php';

$cliente_id = (int)$_SESSION['cliente_id'];
$accion = filter_input(INPUT_POST,'accion',FILTER_SANITIZE_STRING) ?? '';

if($accion == 'listar'){
    $q = mysqli_query($conn, "SELECT * FROM documentos WHERE cliente_id=$cliente_id ORDER BY id DESC");
    echo "<table class='table table-striped datatable' style='width:100%'><thead><tr><th>ID</th><th>Tipo</th><th>Archivo</th><th>Fecha</th><th>Acción</th></tr></thead><tbody>";
    while($r = mysqli_fetch_assoc($q)){
        $id = $r['id'];
        $tipo = htmlspecialchars($r['tipo']);
        $archivo = htmlspecialchars($r['archivo']);
        $fecha = htmlspecialchars($r['fecha']);
        $link = "../uploads/" . $archivo;
        echo "<tr><td>{$id}</td><td>{$tipo}</td><td><a class='btn btn-sm btn-link' href='{$link}' target='_blank'>Ver</a></td><td>{$fecha}</td><td><button class='btn btn-sm btn-danger' onclick='eliminarDoc({$id})'>Eliminar</button></td></tr>";
    }
    echo "</tbody></table>";
    exit;
}

if($accion == 'subir'){
    $tipo = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'tipo',FILTER_UNSAFE_RAW) ?? '');
    if(!isset($_FILES['archivo'])){ echo "Archivo no recibido"; exit; }
    try{
        global $ALLOWED_DOCS;
        $name = upload_file_simple($_FILES['archivo'], $ALLOWED_DOCS);
        $name_db = mysqli_real_escape_string($conn, $name);
        mysqli_query($conn, "INSERT INTO documentos (cliente_id, tipo, archivo) VALUES ($cliente_id, '$tipo', '$name_db')");
        echo "<p style='color:green'>Archivo subido correctamente</p>";
    } catch(Exception $e){
        echo "<p style='color:red'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    exit;
}

if($accion == 'eliminar'){
    $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
    if(!$id){ echo "ID inválido"; exit; }
    $r = mysqli_query($conn, "SELECT archivo, cliente_id FROM documentos WHERE id=$id LIMIT 1");
    if($row = mysqli_fetch_assoc($r)){
        if((int)$row['cliente_id'] !== $cliente_id){ echo "No autorizado"; exit; }
        $archivo = $row['archivo'];
        @unlink(__DIR__ . '/../uploads/' . $archivo);
        mysqli_query($conn, "DELETE FROM documentos WHERE id=$id");
        echo "Documento eliminado";
    } else {
        echo "Documento no encontrado";
    }
    exit;
}

echo "Accion no reconocida";
