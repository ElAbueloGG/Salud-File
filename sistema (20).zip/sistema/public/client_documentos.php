<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if(!isset($_SESSION['cliente_id'])){
    header('Location: client_login.php');
    exit;
}
require __DIR__ . '/../includes/db.php';

// Determine cliente display name safely: prefer session key, then normalized user_nombre, then DB lookup
$cliente_nombre = '';
if(isset($_SESSION['cliente_nombre']) && $_SESSION['cliente_nombre']){
    $cliente_nombre = $_SESSION['cliente_nombre'];
} elseif(isset($_SESSION['user_nombre']) && $_SESSION['user_nombre']){
    $cliente_nombre = $_SESSION['user_nombre'];
} else {
    $cid = (int)($_SESSION['cliente_id'] ?? 0);
    if($cid){
        $r = mysqli_query($conn, "SELECT nombre FROM clientes WHERE id=$cid LIMIT 1");
        if($r && mysqli_num_rows($r)){
            $row = mysqli_fetch_assoc($r);
            $cliente_nombre = $row['nombre'];
        }
    }
}
?>
<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Mis Documentos - <?php echo htmlspecialchars($cliente_nombre); ?></h2>

</div>

<div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title">Subir documento</h5>
        <form id="formDoc" enctype="multipart/form-data">
            <input type="hidden" name="cliente_id" value="<?php echo (int)$_SESSION['cliente_id']; ?>">
            <div class="row">
                <div class="col-md-4">
                    <select name="tipo" class="form-select" required>
                        <option value="Receta">Receta</option>
                        <option value="Acta de nacimiento">Acta de nacimiento</option>
                        <option value="CURP">CURP</option>
                        <option value="INE">INE</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <input type="file" name="archivo" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-primary">Subir</button>
                </div>
            </div>
        </form>
        <div id="msgDoc" class="mt-2"></div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h5 class="card-title">Documentos subidos</h5>
        <div id="listaDocs">Cargando...</div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
function cargarDocs(){
        let f = new FormData(); f.append('accion','listar');
        enviarAjax('client_documentos_ajax.php', f, function(resp){
                document.getElementById('listaDocs').innerHTML = resp;
                if(window.jQuery && $.fn.dataTable) $('.datatable').DataTable({dom:'Bfrtip', buttons:['copy','excel','pdf','print'], responsive: true, language:{ url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' }});
        });
}
cargarDocs();

$('#formDoc').on('submit', function(e){
        e.preventDefault();
        let f = new FormData(this); f.append('accion','subir');
        enviarAjax('client_documentos_ajax.php', f, function(resp){ Swal.fire({icon:'success', title:'Hecho', text:resp}); document.getElementById('formDoc').reset(); cargarDocs(); });
});

function eliminarDoc(id){
        Swal.fire({title:'Confirmar', text:'¿Eliminar documento?', icon:'warning', showCancelButton:true}).then((r)=>{ if(r.isConfirmed){ let f=new FormData(); f.append('accion','eliminar'); f.append('id',id); enviarAjax('client_documentos_ajax.php', f, function(resp){ Swal.fire({text:resp}); cargarDocs(); }); } });
}
</script>
