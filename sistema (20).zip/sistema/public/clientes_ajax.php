<?php
if (session_status() === PHP_SESSION_NONE) session_start();
// Allow legacy `usuario` session or the new normalized `user_type`/`user_id`
if (!((isset($_SESSION["usuario"]) ) || (isset($_SESSION['user_type']) && isset($_SESSION['user_id'])))) {
    header("Location: index.php");
    exit;
}

require "../includes/db.php";

// Leer entradas POST de forma segura
$accion = filter_input(INPUT_POST, 'accion', FILTER_SANITIZE_STRING) ?? '';


// LISTAR
if($accion == "listar"){
    // Check if `status` column exists to avoid SQL errors on older schemas
    $has_status = false;
    $colCheck = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'status'");
    if($colCheck && mysqli_num_rows($colCheck) > 0) $has_status = true;

    // allow requesting inactive entries explicitly
    $show_inactivos = isset($_POST['inactivos']) && $_POST['inactivos'] == '1';
    if($has_status){
        if($show_inactivos){
            $q = mysqli_query($conn, "SELECT * FROM clientes WHERE status=0 ORDER BY id DESC");
        } else {
            $q = mysqli_query($conn, "SELECT * FROM clientes WHERE status=1 ORDER BY id DESC");
        }
    } else {
        $q = mysqli_query($conn, "SELECT * FROM clientes ORDER BY id DESC");
    }

    // detectar si existen columnas para mostrar creador/fecha
    $has_empleado_reg_id = false;
    $has_registrado_por_tipo = false;
    $has_fecha_registro = false;
    $cchk = mysqli_query($conn, "SHOW COLUMNS FROM clientes");
    $cols = [];
    while($cc = mysqli_fetch_assoc($cchk)) $cols[] = $cc['Field'];
    if(in_array('empleado_reg_id',$cols)) $has_empleado_reg_id = true;
    if(in_array('registrado_por_tipo',$cols)) $has_registrado_por_tipo = true;
    if(in_array('fecha_registro',$cols)) $has_fecha_registro = true;

    $html = "<table class='table table-striped datatable' style='width:100%'>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Teléfono</th>
                    <th>Dirección</th>
                    <th>Email</th>";
    if($has_empleado_reg_id) $html .= "<th>Registrado por</th>";
    if($has_fecha_registro) $html .= "<th>Fecha de Registro</th>";
    $html .= "<th>Acciones</th></tr>
                </thead>
                <tbody>";

    while($c = mysqli_fetch_assoc($q)){
        $is_active = true;
        if($has_status){
            $is_active = ((int)$c['status'] === 1);
        }
        $row_class = $is_active ? '' : 'table-danger';
        $html .= "<tr class='{$row_class}'>
            <td>{$c['id']}</td>
            <td>{$c['nombre']}</td>
            <td>{$c['telefono']}</td>
            <td>{$c['direccion']}</td>
            <td>{$c['email']}</td>";

        // Mostrar quién registró al cliente
        if($has_empleado_reg_id){
            $registradoPor = '<span class="badge bg-secondary">Auto-registrado</span>';
            $empleado_id = (int)($c['empleado_reg_id'] ?? 0);
            $tipo = $has_registrado_por_tipo ? ($c['registrado_por_tipo'] ?? '') : '';
            
            if($empleado_id > 0){
                $found = false;
                
                // IMPORTANTE: Usar el tipo para saber en qué tabla buscar
                if($tipo === 'admin'){
                    // Buscar SOLO en usuarios (admin)
                    $r1 = mysqli_query($conn, "SELECT nombre, rol_id FROM usuarios WHERE id=$empleado_id LIMIT 1");
                    if($r1 && mysqli_num_rows($r1)){
                        $u = mysqli_fetch_assoc($r1);
                        $badge = '<span class="badge bg-danger">Admin</span>';
                        $registradoPor = htmlspecialchars($u['nombre']) . " " . $badge;
                        $found = true;
                    }
                } elseif($tipo === 'empleado'){
                    // Primero intentar en usuarios (empleados con cuenta de usuario)
                    $r1 = mysqli_query($conn, "SELECT nombre, rol_id FROM usuarios WHERE id=$empleado_id AND rol_id=2 LIMIT 1");
                    if($r1 && mysqli_num_rows($r1)){
                        $u = mysqli_fetch_assoc($r1);
                        $badge = '<span class="badge bg-primary">Empleado</span>';
                        $registradoPor = htmlspecialchars($u['nombre']) . " " . $badge;
                        $found = true;
                    } else {
                        // Si no está en usuarios, buscar en empleados
                        $r2 = mysqli_query($conn, "SELECT nombre, puesto FROM empleados WHERE id=$empleado_id LIMIT 1");
                        if($r2 && mysqli_num_rows($r2)){
                            $e = mysqli_fetch_assoc($r2);
                            $puesto = htmlspecialchars($e['puesto'] ?? 'Empleado');
                            $badge = '<span class="badge bg-primary">Empleado</span>';
                            $registradoPor = htmlspecialchars($e['nombre']) . " " . $badge . "<br><small class='text-muted'>{$puesto}</small>";
                            $found = true;
                        }
                    }
                } elseif($tipo === 'staff'){
                    // Buscar en usuarios (staff genérico)
                    $r1 = mysqli_query($conn, "SELECT nombre, rol_id FROM usuarios WHERE id=$empleado_id LIMIT 1");
                    if($r1 && mysqli_num_rows($r1)){
                        $u = mysqli_fetch_assoc($r1);
                        $badge = '<span class="badge bg-info">Staff</span>';
                        $registradoPor = htmlspecialchars($u['nombre']) . " " . $badge;
                        $found = true;
                    }
                } elseif($tipo === 'cliente'){
                    // Buscar en clientes
                    $r3 = mysqli_query($conn, "SELECT nombre FROM clientes WHERE id=$empleado_id LIMIT 1");
                    if($r3 && mysqli_num_rows($r3)){
                        $cl = mysqli_fetch_assoc($r3);
                        $badge = '<span class="badge bg-warning">Cliente</span>';
                        $registradoPor = htmlspecialchars($cl['nombre']) . " " . $badge;
                        $found = true;
                    }
                } else {
                    // Sin tipo definido: buscar en usuarios primero, luego empleados
                    $r1 = mysqli_query($conn, "SELECT nombre, rol_id FROM usuarios WHERE id=$empleado_id LIMIT 1");
                    if($r1 && mysqli_num_rows($r1)){
                        $u = mysqli_fetch_assoc($r1);
                        $rol_id = (int)($u['rol_id'] ?? 0);
                        if($rol_id === 1){
                            $badge = '<span class="badge bg-danger">Admin</span>';
                        } elseif($rol_id === 2){
                            $badge = '<span class="badge bg-primary">Empleado</span>';
                        } else {
                            $badge = '<span class="badge bg-info">Staff</span>';
                        }
                        $registradoPor = htmlspecialchars($u['nombre']) . " " . $badge;
                        $found = true;
                    } else {
                        // Buscar en empleados
                        $r2 = mysqli_query($conn, "SELECT nombre, puesto FROM empleados WHERE id=$empleado_id LIMIT 1");
                        if($r2 && mysqli_num_rows($r2)){
                            $e = mysqli_fetch_assoc($r2);
                            $puesto = htmlspecialchars($e['puesto'] ?? 'Empleado');
                            $badge = '<span class="badge bg-primary">Empleado</span>';
                            $registradoPor = htmlspecialchars($e['nombre']) . " " . $badge . "<br><small class='text-muted'>{$puesto}</small>";
                            $found = true;
                        }
                    }
                }
                
                // Si no se encontró en ninguna tabla
                if(!$found){
                    $registradoPor = "<small class='text-muted'>ID: {$empleado_id} (Tipo: {$tipo})</small>";
                }
            }
            $html .= "<td>" . $registradoPor . "</td>";
        }

        // Mostrar fecha y hora de registro
        if($has_fecha_registro){
            $fechaRegistro = '-';
            if(!empty($c['fecha_registro'])){
                // Formatear fecha y hora en español
                $timestamp = strtotime($c['fecha_registro']);
                $fechaRegistro = date('d/m/Y', $timestamp) . "<br><small class='text-muted'>" . date('H:i:s', $timestamp) . "</small>";
            }
            $html .= "<td>" . $fechaRegistro . "</td>";
        }

        $html .= "<td>";
        if($is_active){
            $html .= "<button class='btn btn-sm btn-primary' onclick='verEditar({$c['id']})'>Editar</button> ";
            $html .= "<button class='btn btn-sm btn-danger' onclick='eliminarCliente({$c['id']})'>Dar de baja</button>";
        } else {
            $html .= "<button class='btn btn-sm btn-success' onclick='activarCliente({$c['id']})'>Reactivar</button>";
        }
        $html .= "</td></tr>";
    }

    $html .= "</tbody></table>";
    echo $html;
    exit;
}


// ACTIVAR
if($accion == 'activar'){
    $id = (int)(filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT) ?? 0);
    if($id){
        $react_by = 'NULL';
        if(isset($_SESSION['user_type']) && $_SESSION['user_type']==='staff' && isset($_SESSION['user_id'])){
            $react_by = (int)$_SESSION['user_id'];
        }
        // set status=1 and clear deactivated fields — only touch columns that exist in the schema
        $has_reactivated = false;
        $chk1 = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'reactivated_by'");
        if($chk1 && mysqli_num_rows($chk1) > 0) $has_reactivated = true;
        $has_deactivated_by = false;
        $chk2 = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'deactivated_by'");
        if($chk2 && mysqli_num_rows($chk2) > 0) $has_deactivated_by = true;

        $parts = ["status=1", "deactivated_at=NULL"];
        if($has_deactivated_by){
            $parts[] = "deactivated_by=NULL";
        }
        if($has_reactivated && is_numeric($react_by)){
            $parts[] = "reactivated_by=$react_by";
        }
        $sql = "UPDATE clientes SET " . implode(',', $parts) . " WHERE id=$id";
        if(mysqli_query($conn, $sql)){
            // enviar correo opcional
            $r = mysqli_query($conn, "SELECT email,nombre FROM clientes WHERE id=$id");
            if($r && mysqli_num_rows($r)){
                $c = mysqli_fetch_assoc($r);
                if($c['email']){
                    require_once __DIR__ . '/../includes/functions.php';
                    $subject = "Cuenta reactivada";
                    $msg = "Hola {$c['nombre']},\n\nTu cuenta ha sido reactivada. Puedes iniciar sesión normalmente.";
                    send_mail_simple($c['email'], $subject, $msg);
                }
            }
            echo "Cliente reactivado";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "ID inválido";
    }
    exit;
}



// AGREGAR
if($accion == "agregar"){
    $nombre    = mysqli_real_escape_string($conn, filter_input(INPUT_POST, 'nombre', FILTER_UNSAFE_RAW) ?? '');
    $telefono  = mysqli_real_escape_string($conn, filter_input(INPUT_POST, 'telefono', FILTER_UNSAFE_RAW) ?? '');
    $direccion = mysqli_real_escape_string($conn, filter_input(INPUT_POST, 'direccion', FILTER_UNSAFE_RAW) ?? '');
    $email     = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '');
    $esc_email = ''; // Inicializar variable
    
    // only allow setting password when requested by an admin
    $password = '';
    if(isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 1){
        $password = $_POST['password'] ?? '';
    }

    // Validar y escapar email
    if($email){
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            echo "Correo inválido"; exit;
        }
        $esc_email = mysqli_real_escape_string($conn, $email);
        
        // DEBUG: Log de validación de email
        $email_log = "VALIDACIÓN EMAIL:\n";
        $email_log .= "Email original: '$email'\n";
        $email_log .= "Email escapado: '$esc_email'\n";
        
        // comprobar email único
        $check = mysqli_query($conn, "SELECT id, nombre, email FROM clientes WHERE email='$esc_email' LIMIT 1");
        $email_log .= "Query: SELECT id, nombre, email FROM clientes WHERE email='$esc_email' LIMIT 1\n";
        $email_log .= "Resultados encontrados: " . mysqli_num_rows($check) . "\n";
        
        if($check && mysqli_num_rows($check) > 0){
            $existing = mysqli_fetch_assoc($check);
            $email_log .= "Cliente existente: ID={$existing['id']}, Nombre={$existing['nombre']}, Email={$existing['email']}\n";
            @file_put_contents(__DIR__ . '/../logs/email_validation.log', $email_log . "---\n", FILE_APPEND);
            echo "Ya existe una cuenta con ese correo"; exit;
        }
        
        $email_log .= "Email disponible - OK\n";
        @file_put_contents(__DIR__ . '/../logs/email_validation.log', $email_log . "---\n", FILE_APPEND);
    }

    // Obtener el ID y tipo del usuario que está registrando al cliente
    $empleado_reg_id = 0;
    $registrado_por_tipo = NULL;
    
    // DEBUG: Guardar en log para diagnóstico
    $debug_log = "DEBUG AGREGAR CLIENTE:\n";
    $debug_log .= "user_type: " . ($_SESSION['user_type'] ?? 'NO DEFINIDO') . "\n";
    $debug_log .= "user_id: " . ($_SESSION['user_id'] ?? 'NO DEFINIDO') . "\n";
    $debug_log .= "empleado_id: " . ($_SESSION['empleado_id'] ?? 'NO DEFINIDO') . "\n";
    $debug_log .= "rol_id: " . ($_SESSION['rol_id'] ?? 'NO DEFINIDO') . "\n";
    $debug_log .= "rol_nombre: " . ($_SESSION['rol_nombre'] ?? 'NO DEFINIDO') . "\n";
    
    if(isset($_SESSION['user_type']) && $_SESSION['user_type']==='staff'){
        // Determinar si es de tabla usuarios o empleados
        if(isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0){
            // Login desde tabla usuarios
            $empleado_reg_id = (int)$_SESSION['user_id'];
            // Determinar el tipo según rol_id
            if(isset($_SESSION['rol_id'])){
                $rol_id = (int)$_SESSION['rol_id'];
                $registrado_por_tipo = ($rol_id === 1) ? 'admin' : 'empleado';
                $debug_log .= "CASO: Login desde usuarios, rol_id=$rol_id, tipo=$registrado_por_tipo\n";
            } else {
                $registrado_por_tipo = 'staff';
                $debug_log .= "CASO: Login desde usuarios, sin rol_id, tipo=staff\n";
            }
        } elseif(isset($_SESSION['empleado_id']) && $_SESSION['empleado_id'] > 0){
            // Login desde tabla empleados
            $empleado_reg_id = (int)$_SESSION['empleado_id'];
            $registrado_por_tipo = 'empleado';
            $debug_log .= "CASO: Login desde empleados, empleado_id=$empleado_reg_id\n";
        }
    } elseif(isset($_SESSION['user_type']) && $_SESSION['user_type']==='cliente'){
        // Un cliente registrando (caso raro, pero por si acaso)
        if(isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0){
            $empleado_reg_id = (int)$_SESSION['user_id'];
            $registrado_por_tipo = 'cliente';
            $debug_log .= "CASO: Cliente registrando\n";
        }
    }
    
    $debug_log .= "RESULTADO: empleado_reg_id=$empleado_reg_id, tipo=$registrado_por_tipo\n";
    $debug_log .= "---\n";
    
    // Guardar log
    $logdir = __DIR__ . '/../logs';
    if(!is_dir($logdir)) @mkdir($logdir, 0777, true);
    @file_put_contents($logdir . '/registro_clientes.log', $debug_log, FILE_APPEND);

    // contraseña en texto plano por petición (no recomendado)
    $raw_pass = '';
    if($password) $raw_pass = mysqli_real_escape_string($conn, $password);

    // Verificar si existe la columna registrado_por_tipo
    $has_registrado_por_tipo = false;
    $colCheck3 = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'registrado_por_tipo'");
    if($colCheck3 && mysqli_num_rows($colCheck3) > 0) $has_registrado_por_tipo = true;

    // Construir INSERT incluyendo empleado_reg_id y tipo
    $fields = [ 'nombre', 'telefono', 'direccion', 'empleado_reg_id' ];
    $values = [ "'{$nombre}'", "'{$telefono}'", "'{$direccion}'", $empleado_reg_id ];
    
    // Email es requerido según el esquema
    if($email && $esc_email){
        $fields[] = 'email';
        $values[] = "'{$esc_email}'";
    } else {
        // Si no hay email, usar uno vacío o generar uno temporal
        $fields[] = 'email';
        $values[] = "''";
    }
    
    // Password es requerido según el esquema
    if($password && $raw_pass){
        $fields[] = 'password';
        $values[] = "'{$raw_pass}'";
    } else {
        $fields[] = 'password';
        $values[] = "''";
    }
    
    if($has_registrado_por_tipo && $registrado_por_tipo !== NULL){
        $fields[] = 'registrado_por_tipo';
        $values[] = "'{$registrado_por_tipo}'";
    }

    $sql = "INSERT INTO clientes (" . implode(',', $fields) . ") VALUES (" . implode(',', $values) . ")";
    
    // Debug: guardar SQL en log
    @file_put_contents(__DIR__ . '/../logs/registro_clientes.log', "SQL: $sql\n", FILE_APPEND);
    if(mysqli_query($conn, $sql)){
        echo "Cliente agregado correctamente";
        
        // Enviar correo de notificación al cliente
        if($email){
            require_once __DIR__ . '/../includes/functions.php';
            $subject = "Envio de datos de registro";
            $message = "Hola, bienvenido al sistema.\n";
            $message .= "Tus datos son: Usuario $email\n";
            if($password){
                $message .= "Tu contraseña es: $password\n";
            }
            $message .= "\nPuedes iniciar sesión en: " . (isset($_SERVER['HTTP_HOST']) ? "http://{$_SERVER['HTTP_HOST']}/sistema/public/client_login.php" : "http://localhost/sistema/public/client_login.php") . "\n\n";
            $message .= "Saludos,\nEquipo SALUD-FILE";
            send_mail_simple($email, $subject, $message);
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
    exit;
}



// ELIMINAR
    if($accion == "eliminar"){
    $id = (int)(filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT) ?? 0);
    if($id){
        // soft-delete: marcar status=0 y registrar quién lo desactivó
        $deact_by = 'NULL';
        if(isset($_SESSION['user_type']) && $_SESSION['user_type']==='staff' && isset($_SESSION['user_id'])){
            $deact_by = (int)$_SESSION['user_id'];
        }
        $sql = "UPDATE clientes SET status=0, deactivated_at=NOW()" . (is_numeric($deact_by)? ", deactivated_by=$deact_by":"") . " WHERE id=$id";
        if(mysqli_query($conn, $sql)){
            // enviar correo al cliente si tiene email
            $r = mysqli_query($conn, "SELECT email,nombre FROM clientes WHERE id=$id");
            if($r && mysqli_num_rows($r)){
                $c = mysqli_fetch_assoc($r);
                if($c['email']){
                    require_once __DIR__ . '/../includes/functions.php';
                    $subject = "Cuenta dada de baja";
                    $msg = "Hola {$c['nombre']},\n\nSu cuenta ha sido dada de baja. Si crees que es un error, contacta al administrador.";
                    send_mail_simple($c['email'], $subject, $msg);
                }
            }
            echo "Cliente dado de baja";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "ID inválido";
    }
    exit;
}



// VER DATOS PARA EDITAR
if($accion == "ver"){
    $id = (int)(filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT) ?? 0);
    $q = mysqli_query($conn, "SELECT * FROM clientes WHERE id=$id");
    $c = mysqli_fetch_assoc($q);

    ?>
        <div class="card mt-3">
            <div class="card-body">
                <h5 class="card-title">Editar cliente</h5>
                <div class="mb-2">
                    <label class="form-label">Nombre</label>
                    <input id="edit_nombre" class="form-control" value="<?=htmlspecialchars($c['nombre'])?>">
                </div>
                <div class="mb-2">
                    <label class="form-label">Teléfono</label>
                    <input id="edit_telefono" class="form-control" value="<?=htmlspecialchars($c['telefono'])?>">
                </div>
                <div class="mb-2">
                    <label class="form-label">Dirección</label>
                    <textarea id="edit_direccion" class="form-control"><?=htmlspecialchars($c['direccion'])?></textarea>
                </div>
                <div class="mb-2">
                    <label class="form-label">Email</label>
                    <input id="edit_email" class="form-control" value="<?=htmlspecialchars($c['email'] ?? '')?>">
                </div>
                <?php if(isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 1): ?>
                <div class="mb-2">
                    <label class="form-label">Contraseña (solo admin)</label>
                    <input id="edit_password" type="password" class="form-control" placeholder="Nueva contraseña (dejar vacío para no cambiar)">
                </div>
                <?php endif; ?>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button class="btn btn-primary" onclick="guardarEdicion(<?=$c['id']?>)">Guardar cambios</button>
                    <button class="btn btn-secondary" onclick="document.getElementById('msg').innerHTML=''">Cancelar</button>
                </div>
            </div>
        </div>
    <?php
    exit;
}



// GUARDAR EDICIÓN
if($accion == "editar"){

    $id        = (int)(filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT) ?? 0);
    $nombre    = mysqli_real_escape_string($conn, filter_input(INPUT_POST, 'nombre', FILTER_UNSAFE_RAW) ?? '');
    $telefono  = mysqli_real_escape_string($conn, filter_input(INPUT_POST, 'telefono', FILTER_UNSAFE_RAW) ?? '');
    $direccion = mysqli_real_escape_string($conn, filter_input(INPUT_POST, 'direccion', FILTER_UNSAFE_RAW) ?? '');
    $email     = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '');

    if($email && !filter_var($email, FILTER_VALIDATE_EMAIL)){
        echo "Correo inválido"; exit;
    }

    // comprobar email único (excluyendo el mismo cliente)
    if($email){
        $esc_email = mysqli_real_escape_string($conn, $email);
        $chk = mysqli_query($conn, "SELECT id FROM clientes WHERE email='$esc_email' AND id<>$id LIMIT 1");
        if($chk && mysqli_num_rows($chk) > 0){
            echo "Ya existe una cuenta con ese correo"; exit;
        }
    }

    // update including email if present; password can only be changed by admin
    $sets = [];
    $sets[] = "nombre='".mysqli_real_escape_string($conn,$nombre)."'";
    $sets[] = "telefono='".mysqli_real_escape_string($conn,$telefono)."'";
    $sets[] = "direccion='".mysqli_real_escape_string($conn,$direccion)."'";
    if($email) $sets[] = "email='".mysqli_real_escape_string($conn,$email)."'";
    // handle password change only for admin
    if(isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 1){
        $newpass = $_POST['password'] ?? '';
        if($newpass){
            $esc_newpass = mysqli_real_escape_string($conn, $newpass);
            $sets[] = "password='".$esc_newpass."'";
        }
    }

    mysqli_query($conn, "UPDATE clientes SET " . implode(',', $sets) . " WHERE id=$id");

    echo "Cambios guardados";
    exit;
}
