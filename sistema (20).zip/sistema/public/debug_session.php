<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug Sesión</title>
    <style>
        body { font-family: monospace; padding: 20px; }
        .session-data { background: #f5f5f5; padding: 15px; border-radius: 5px; }
        .key { color: #0066cc; font-weight: bold; }
        .value { color: #cc0000; }
    </style>
</head>
<body>
    <h1>Datos de Sesión Actual</h1>
    <div class="session-data">
        <?php
        if(empty($_SESSION)){
            echo "<p>No hay sesión activa</p>";
        } else {
            echo "<pre>";
            foreach($_SESSION as $key => $value){
                echo "<span class='key'>" . htmlspecialchars($key) . "</span>: ";
                echo "<span class='value'>" . htmlspecialchars(print_r($value, true)) . "</span>\n";
            }
            echo "</pre>";
        }
        ?>
    </div>
    
    <h2>Información Relevante</h2>
    <ul>
        <li><strong>user_type:</strong> <?php echo $_SESSION['user_type'] ?? 'NO DEFINIDO'; ?></li>
        <li><strong>user_id:</strong> <?php echo $_SESSION['user_id'] ?? 'NO DEFINIDO'; ?></li>
        <li><strong>empleado_id:</strong> <?php echo $_SESSION['empleado_id'] ?? 'NO DEFINIDO'; ?></li>
        <li><strong>rol_id:</strong> <?php echo $_SESSION['rol_id'] ?? 'NO DEFINIDO'; ?></li>
        <li><strong>rol_nombre:</strong> <?php echo $_SESSION['rol_nombre'] ?? 'NO DEFINIDO'; ?></li>
        <li><strong>user_nombre:</strong> <?php echo $_SESSION['user_nombre'] ?? 'NO DEFINIDO'; ?></li>
    </ul>
    
    <h2>Consulta a Base de Datos</h2>
    <?php
    require_once __DIR__ . '/../includes/db.php';
    
    if(isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0){
        $user_id = (int)$_SESSION['user_id'];
        echo "<h3>Buscando en tabla usuarios con ID: $user_id</h3>";
        $q = mysqli_query($conn, "SELECT * FROM usuarios WHERE id=$user_id");
        if($q && mysqli_num_rows($q) > 0){
            $u = mysqli_fetch_assoc($q);
            echo "<pre>";
            print_r($u);
            echo "</pre>";
        } else {
            echo "<p style='color: red;'>NO ENCONTRADO en tabla usuarios</p>";
        }
    }
    
    if(isset($_SESSION['empleado_id']) && $_SESSION['empleado_id'] > 0){
        $emp_id = (int)$_SESSION['empleado_id'];
        echo "<h3>Buscando en tabla empleados con ID: $emp_id</h3>";
        $q = mysqli_query($conn, "SELECT * FROM empleados WHERE id=$emp_id");
        if($q && mysqli_num_rows($q) > 0){
            $e = mysqli_fetch_assoc($q);
            echo "<pre>";
            print_r($e);
            echo "</pre>";
        } else {
            echo "<p style='color: red;'>NO ENCONTRADO en tabla empleados</p>";
        }
    }
    ?>
    
    <p><a href="dashboard.php">Volver al Dashboard</a></p>
</body>
</html>
