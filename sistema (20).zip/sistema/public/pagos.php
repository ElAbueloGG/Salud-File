<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Sólo el personal (administrador o empleado) debe gestionar pagos desde esta página.
if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff'){
    header('Location: login.php');
    exit;
}
?>

<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Gestión de Pagos</h2>
    <a class="btn btn-secondary" href="dashboard.php">⬅ Volver</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title">Registrar pago</h5>
        <form id="formPago" enctype="multipart/form-data">
            <div class="row g-2">
                <div class="col-md-4">
                    <select name="cliente_id" class="form-select" required>
                        <option value="">Selecciona cliente</option>
                        <?php
                        // tolerate missing status column
                        $has_status = false;
                        $col = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'status'");
                        if($col && mysqli_num_rows($col) > 0) $has_status = true;
                        if($has_status){
                            $res = mysqli_query($conn, "SELECT id,nombre FROM clientes WHERE status=1 ORDER BY nombre");
                        } else {
                            $res = mysqli_query($conn, "SELECT id,nombre FROM clientes ORDER BY nombre");
                        }
                        while($c = mysqli_fetch_assoc($res)){
                            echo "<option value=\"{$c['id']}\">".htmlspecialchars($c['nombre'])."</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2"><input name="monto" class="form-control" placeholder="Monto (ej. 250.00)" required></div>
                <div class="col-md-2"><input name="referencia" class="form-control" placeholder="Referencia" required></div>
                <div class="col-md-2"><input name="motivo" class="form-control" placeholder="Motivo"></div>
                <div class="col-md-2"><input type="file" name="comprobante" class="form-control"></div>
            </div>
            <div class="mt-2"><button class="btn btn-primary">Registrar</button></div>
        </form>
        <div id="msgPago" class="mt-2"></div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h5 class="card-title">Pagos registrados</h5>
        <div id="listaPagos">Cargando...</div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
function cargarPagos(){
    let f=new FormData(); f.append('accion','listar');
    enviarAjax('pagos_ajax.php', f, function(resp){
        document.getElementById('listaPagos').innerHTML = resp;
        if(window.jQuery && $.fn.dataTable){
            if($.fn.dataTable.isDataTable('.datatable')){
                try{ $('.datatable').DataTable().destroy(); }catch(e){}
            }
            $('.datatable').DataTable({
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                     '<"row"<"col-sm-12"B>>' +
                     '<"row"<"col-sm-12"tr>>' +
                     '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                buttons: [
                    { extend: 'copy', text: 'Copiar', className: 'buttons-copy' },
                    { extend: 'excel', text: 'Excel', className: 'buttons-excel', title: 'SaludFile - Pagos' },
                    { 
                        extend: 'pdf', 
                        text: 'PDF', 
                        className: 'buttons-pdf',
                        title: 'SaludFile - Pagos',
                        orientation: 'landscape',
                        pageSize: 'A4',
                        exportOptions: {
                            columns: ':visible',
                            stripHtml: true
                        },
                        customize: function(doc) {
                            doc.pageMargins = [40, 100, 40, 50];
                            
                            // Header minimalista y elegante
                            doc.header = function(currentPage, pageCount) {
                                return {
                                    margin: [40, 25, 40, 0],
                                    columns: [
                                        {
                                            width: 'auto',
                                            text: 'SaludFile',
                                            fontSize: 20,
                                            bold: true,
                                            color: '#155DFC'
                                        },
                                        {
                                            width: '*',
                                            text: 'Pagos',
                                            fontSize: 20,
                                            color: '#64748b',
                                            alignment: 'left',
                                            margin: [8, 0, 0, 0]
                                        }
                                    ]
                                };
                            };
                            
                            // Footer minimalista
                            doc.footer = function(currentPage, pageCount) {
                                return {
                                    margin: [40, 15, 40, 0],
                                    columns: [
                                        { 
                                            text: new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' }), 
                                            fontSize: 8, 
                                            color: '#94a3b8' 
                                        },
                                        { 
                                            text: currentPage + ' / ' + pageCount, 
                                            alignment: 'right', 
                                            fontSize: 8, 
                                            color: '#94a3b8' 
                                        }
                                    ]
                                };
                            };
                            
                            // Estilos de tabla minimalistas
                            doc.defaultStyle = {
                                fontSize: 9
                            };
                            
                            doc.styles.tableHeader = {
                                fontSize: 9,
                                bold: true,
                                fillColor: '#f8fafc',
                                color: '#1e293b',
                                alignment: 'left'
                            };
                            
                            // Configuración de tabla
                            if(doc.content[0] && doc.content[0].table) {
                                var table = doc.content[0].table;
                                table.widths = Array(table.body[0].length).fill('auto');
                                table.layout = {
                                    hLineWidth: function(i, node) { 
                                        return (i === 1) ? 1.5 : 0.5;
                                    },
                                    vLineWidth: function(i) { return 0; },
                                    hLineColor: function(i, node) { 
                                        return (i === 1) ? '#155DFC' : '#e2e8f0';
                                    },
                                    fillColor: function(i) { 
                                        return (i === 0) ? '#f8fafc' : (i % 2 === 0) ? '#fafbfc' : null;
                                    },
                                    paddingLeft: function(i) { return i === 0 ? 0 : 8; },
                                    paddingRight: function(i, node) { return (i === node.table.widths.length - 1) ? 0 : 8; },
                                    paddingTop: function() { return 8; },
                                    paddingBottom: function() { return 8; }
                                };
                            }
                        }
                    },
                    { extend: 'print', text: 'Imprimir', className: 'buttons-print', title: 'SaludFile - Pagos' }
                ],
                responsive: true,
                pageLength: 10,
                lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
                language: { 
                    url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
                    buttons: {
                        copy: 'Copiar',
                        copyTitle: 'Copiado',
                        copySuccess: { _: '%d filas copiadas', 1: '1 fila copiada' }
                    }
                },
                order: [[0, 'desc']]
            });
        }
    });
}
cargarPagos();

$('#formPago').on('submit', function(e){
    e.preventDefault();
    let f=new FormData(this); f.append('accion','registrar');
    enviarAjax('pagos_ajax.php', f, function(resp){
        let lower = (resp||'').toLowerCase();
        if(lower.includes('error') || lower.includes('invalid') || lower.includes('no autorizado')){
            Swal.fire({icon:'error', title:'Error', text: resp});
        } else {
            Swal.fire({icon:'success', title:'Hecho', text: resp});
            document.getElementById('formPago').reset();
            cargarPagos();
        }
    });
});

function eliminarPago(id){
    Swal.fire({title:'Confirmar', text:'¿Eliminar pago?', icon:'warning', showCancelButton:true}).then((r)=>{
        if(r.isConfirmed){
            let f=new FormData(); f.append('accion','eliminar'); f.append('id',id);
            enviarAjax('pagos_ajax.php', f, function(resp){
                let lower = (resp||'').toLowerCase();
                if(lower.includes('error') || lower.includes('no autorizado') || lower.includes('no encontrado')){
                    Swal.fire({icon:'error', title:'Error', text: resp});
                } else {
                    Swal.fire({icon:'success', title:'Eliminado', text: resp});
                }
                cargarPagos();
            });
        }
    });
}

function verEditarPago(id){
    let f = new FormData(); f.append('accion','ver'); f.append('id', id);
    enviarAjax('pagos_ajax.php', f, function(resp){ document.getElementById('msgPago').innerHTML = resp; });
}

function abrirVoucher(id, imprimir){
    const url = 'pago_voucher.php?id='+encodeURIComponent(id) + (imprimir ? '&print=1' : '');
    window.open(url, '_blank', 'toolbar=0,location=0,menubar=0');
}

function guardarEdicionPago(id){
    const monto = document.getElementById('edit_monto').value;
    const referencia = document.getElementById('edit_referencia').value;
    const motivo = document.getElementById('edit_motivo').value;
    const form = new FormData();
    form.append('accion','editar'); form.append('id', id);
    form.append('monto', monto); form.append('referencia', referencia); form.append('motivo', motivo);
    const clienteSel = document.getElementById('edit_cliente_id');
    if(clienteSel) form.append('cliente_id', clienteSel.value);
    const fileInput = document.getElementById('edit_comprobante');
    if(fileInput && fileInput.files && fileInput.files.length) form.append('comprobante', fileInput.files[0]);
    enviarAjax('pagos_ajax.php', form, function(resp){
        let lower = (resp||'').toLowerCase();
        if(lower.includes('error') || lower.includes('no autorizado')){
            Swal.fire({icon:'error', title:'Error', text: resp});
        } else {
            Swal.fire({icon:'success', title:'Hecho', text: resp});
            document.getElementById('msgPago').innerHTML = '';
            cargarPagos();
        }
    });
}
</script>
