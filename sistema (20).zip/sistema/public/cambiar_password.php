<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Verificar que el usuario esté autenticado
if(!isset($_SESSION['user_type'])){
  echo 'No autorizado'; exit;
}

$user_type = $_SESSION['user_type'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;
$empleado_id = $_SESSION['empleado_id'] ?? null;

$nueva = $_POST['nueva'] ?? '';
$confirmar = $_POST['confirmar'] ?? '';

// Validaciones
if(!$nueva || !$confirmar){
  echo 'Faltan datos'; exit;
}
if($nueva !== $confirmar){
  echo 'Las contraseñas no coinciden'; exit;
}
if(strlen($nueva) < 4){
  echo 'La nueva contraseña debe tener al menos 4 caracteres'; exit;
}

// Escapar la contraseña (texto plano según especificaciones del sistema)
$newpass_escaped = mysqli_real_escape_string($conn, $nueva);

// Actualizar según el tipo de usuario
$updated = false;

if($user_type === 'cliente' && $user_id){
  $result = mysqli_query($conn, "UPDATE clientes SET password='$newpass_escaped' WHERE id=".(int)$user_id);
  if($result && mysqli_affected_rows($conn) > 0){
    $updated = true;
  }
}

if($user_type === 'staff'){
  // Prioridad a empleado_id (login desde tabla empleados)
  if(!empty($empleado_id)){
    $result = mysqli_query($conn, "UPDATE empleados SET password='$newpass_escaped' WHERE id=".(int)$empleado_id);
    if($result && mysqli_affected_rows($conn) > 0){
      $updated = true;
    }
  }
  // Si no hay empleado_id, usar user_id (login desde tabla usuarios)
  elseif(!empty($user_id)){
    $result = mysqli_query($conn, "UPDATE usuarios SET password='$newpass_escaped' WHERE id=".(int)$user_id);
    if($result && mysqli_affected_rows($conn) > 0){
      $updated = true;
    }
  }
}

if($updated){
  echo 'OK';
} else {
  echo 'No se pudo actualizar la contraseña. Verifica tu sesión.';
}
exit;
