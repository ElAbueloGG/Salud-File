<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$id = (int)($_GET['id'] ?? 0);
$print = isset($_GET['print']) && $_GET['print']=='1';
if(!$id){ echo "Pago inválido"; exit; }

$q = mysqli_query($conn, "SELECT p.*, c.nombre as cliente FROM pagos p JOIN clientes c ON p.cliente_id=c.id WHERE p.id=$id LIMIT 1");
$p = mysqli_fetch_assoc($q);
if(!$p){ echo "Pago no encontrado"; exit; }

// Autorización: solo staff o el cliente propietario pueden ver el voucher
$user_type = $_SESSION['user_type'] ?? (isset($_SESSION['cliente_id'])? 'cliente' : null);
$user_id = $_SESSION['user_id'] ?? ($_SESSION['cliente_id'] ?? null);
if($user_type !== 'staff'){
  if(!$user_id || $p['cliente_id'] != $user_id){
    echo "No autorizado"; exit;
  }
}

$company = $APP_NAME ?? 'Empresa';
$cliente = htmlspecialchars($p['cliente']);
$monto = htmlspecialchars($p['monto']);
$referencia = htmlspecialchars($p['referencia']);
$motivo = htmlspecialchars($p['descripcion'] ?? $p['motivo'] ?? '');
$fecha = htmlspecialchars($p['fecha']);
$comp = htmlspecialchars($p['comprobante']);
// Use absolute uploads URL (adjust if your app runs in a subfolder)
$compUrl = $comp ? ('/sistema/uploads/' . $comp) : '';

?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Voucher Pago #<?php echo $id; ?></title>
  <style>
    body{ font-family: Inter, Arial, sans-serif; padding:20px; color:#111; }
    .voucher{ max-width:650px; margin:0 auto; border:1px solid #ddd; padding:18px; border-radius:8px; }
    .voucher h1{ margin:0 0 8px 0; font-size:20px; }
    .voucher .row{ display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px dashed #eee; }
    .voucher .row:last-child{ border-bottom:none; }
    .label{ color:#555; font-size:0.9rem; }
    .value{ font-weight:700; font-size:1rem; }
    .comp-img{ margin-top:12px; max-width:100%; border:1px solid #ccc; }
    .footer-note{ margin-top:12px; color:#666; font-size:0.85rem; }
    @media print{
      body{ padding:6mm; }
      .voucher{ border:none; box-shadow:none; }
    }
    .actions{ text-align:right; margin-bottom:10px; }
    .btn{ display:inline-block; padding:6px 10px; border-radius:6px; text-decoration:none; color:#fff; background:#0d6efd; }
    .btn.secondary{ background:#6c757d; }
  </style>
</head>
<body>
<div class="actions">
  <a class="btn" href="javascript:window.print();">Imprimir / Guardar PDF</a>
  <a class="btn secondary" href="pago_voucher.php?id=<?php echo $id; ?>">Abrir</a>
</div>
<div class="voucher">
  <h1><?php echo htmlspecialchars($company); ?></h1>
  <p class="label">Comprobante de pago</p>
  <div class="row"><div><span class="label">Cliente</span><div class="value"><?php echo $cliente; ?></div></div><div><span class="label">Monto</span><div class="value">$<?php echo $monto; ?></div></div></div>
  <div class="row"><div><span class="label">Referencia</span><div class="value"><?php echo $referencia; ?></div></div><div><span class="label">Fecha</span><div class="value"><?php echo $fecha; ?></div></div></div>
  <div class="row"><div style="width:100%;"><span class="label">Motivo</span><div class="value"><?php echo $motivo ? $motivo : '-'; ?></div></div></div>
  <?php if($comp): ?>
    <div class="row"><div style="width:100%;"><span class="label">Comprobante</span>
      <div><img class="comp-img" src="<?php echo $compUrl; ?>" alt="Comprobante"></div>
    </div></div>
  <?php endif; ?>
  <div class="footer-note">Generado: <?php echo date('Y-m-d H:i:s'); ?></div>
</div>
<?php if($print): ?>
<script>window.addEventListener('load', function(){ setTimeout(function(){ window.print(); },300); });</script>
<?php endif; ?>
</body>
</html>
