<?php
// Redirige al formulario unificado de login
header('Location: login.php');
exit;
?>
