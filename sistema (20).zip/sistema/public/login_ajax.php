<?php
session_start();
require __DIR__ . "/../includes/config.php";

// Single login: check `usuarios` (staff/admin/empleado) first, then `clientes`.
if (!isset($_POST["email"]) || !isset($_POST["password"])) {
    echo "Faltan datos";
    exit;
}

$email = trim($_POST["email"]);
$password = $_POST["password"];

// normalize
$esc_email = mysqli_real_escape_string($conn, $email);

// 1) check usuarios
$sql = "SELECT u.id,u.nombre,u.email,u.password,u.rol_id,r.nombre as rol_nombre FROM usuarios u LEFT JOIN roles r ON u.rol_id=r.id WHERE u.email='$esc_email' LIMIT 1";
$res = mysqli_query($conn, $sql);
if($res && mysqli_num_rows($res) > 0){
    $u = mysqli_fetch_assoc($res);
    $dbpass = $u['password'];
    $ok = false;
    // support plain or bcrypt (if you used password_hash earlier)
    if(strpos($dbpass,'$2y$')===0 || strpos($dbpass,'$2a$')===0){
        if(password_verify($password,$dbpass)) $ok = true;
    } else {
        if($password === $dbpass) $ok = true;
    }
    if($ok){
        // set session: preserve legacy `usuario` key and add role info
        $_SESSION['usuario'] = $u['email'];
        $_SESSION['user_type'] = 'staff';
        $_SESSION['rol_id'] = (int)$u['rol_id'];
        $_SESSION['rol_nombre'] = $u['rol_nombre'];
        $_SESSION['user_id'] = (int)$u['id'];
        $_SESSION['user_nombre'] = $u['nombre'];
        // return OK with role
        $role = strtolower($u['rol_nombre'] ?? 'staff');
        echo "OK:" . $role;
        exit;
    }
}

// 2) check clientes
// detect if clientes has a status column so we can block inactive accounts
$has_client_status = false;
$rchk = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'status'");
if($rchk && mysqli_num_rows($rchk) > 0) $has_client_status = true;

$select_client_cols = ['id','nombre','email','password'];
if($has_client_status) $select_client_cols[] = 'status';
$sql = "SELECT " . implode(',', $select_client_cols) . " FROM clientes WHERE email='$esc_email' LIMIT 1";
$res = mysqli_query($conn, $sql);
if($res && mysqli_num_rows($res) > 0){
    $c = mysqli_fetch_assoc($res);
    // block if account deactivated
    if(isset($c['status']) && (int)$c['status'] === 0){
        echo "Cuenta desactivada";
        exit;
    }
    $dbpass = $c['password'];
    $ok = false;
    if(strpos($dbpass,'$2y$')===0 || strpos($dbpass,'$2a$')===0){
        if(password_verify($password,$dbpass)) $ok = true;
    } else {
        if($password === $dbpass) $ok = true;
    }
        if($ok){
        $_SESSION['cliente_id'] = (int)$c['id']; // legacy
        $_SESSION['user_type'] = 'cliente';
        $_SESSION['user_id'] = (int)$c['id'];
        $_SESSION['user_nombre'] = $c['nombre'];
        echo "OK:cliente";
        exit;
    }
}

// 3) fallback: check `empleados` table (some installations keep credentials in `empleados`)
$esc = mysqli_real_escape_string($conn, $email);

// detect available columns to avoid querying non-existent fields
$has_email_col = false;
$has_user_col = false;
$r = mysqli_query($conn, "SHOW COLUMNS FROM empleados LIKE 'email'");
if($r && mysqli_num_rows($r) > 0) $has_email_col = true;
$r2 = mysqli_query($conn, "SHOW COLUMNS FROM empleados LIKE 'user'");
if($r2 && mysqli_num_rows($r2) > 0) $has_user_col = true;

// helper function for empleados columns
function empleados_has_col($conn, $colname){
    $res = mysqli_query($conn, "SHOW COLUMNS FROM empleados LIKE '".mysqli_real_escape_string($conn,$colname)."'");
    return ($res && mysqli_num_rows($res) > 0);
}

if($has_email_col || $has_user_col){
    $select_cols = ['id','nombre','password'];
    // include status if available to block inactive empleados
    if(empleados_has_col($conn, 'status')) $select_cols[] = 'status';
    if($has_user_col) $select_cols[] = 'user';
    if($has_email_col) $select_cols[] = 'email';

    $where_parts = [];
    if($has_user_col) $where_parts[] = "`user`='$esc'";
    if($has_email_col) $where_parts[] = "`email`='$esc'";
    $where = implode(' OR ', $where_parts);

    $sql = "SELECT `" . implode('`,`', $select_cols) . "` FROM empleados WHERE $where LIMIT 1";
    $res = @mysqli_query($conn, $sql);
    if($res && mysqli_num_rows($res)>0){
        $e = mysqli_fetch_assoc($res);
        // block if empleado account is deactivated
        if(isset($e['status']) && (int)$e['status'] === 0){
            echo "Cuenta desactivada";
            exit;
        }
        $dbpass = $e['password'] ?? '';
        $ok = false;
        if(strpos($dbpass,'$2y$')===0 || strpos($dbpass,'$2a$')===0){
            if(password_verify($password,$dbpass)) $ok = true;
        } else {
            if($password === $dbpass) $ok = true;
        }
        if($ok){
            $_SESSION['user_type'] = 'staff';
            $_SESSION['rol_id'] = 2; // empleado
            $_SESSION['rol_nombre'] = 'Empleado';
            if(!empty($e['user'])) $_SESSION['usuario'] = $e['user'];
            $_SESSION['user_id'] = 0; // no usuarios.id available
            $_SESSION['empleado_id'] = (int)$e['id'];
            $_SESSION['user_nombre'] = $e['nombre'];
            echo "OK:empleado";
            exit;
        }
    }
}

echo "Datos incorrectos";
exit;
?>

