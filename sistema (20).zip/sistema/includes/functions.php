<?php
require "config.php";

// --------------------------------------
// SUBIR ARCHIVOS SIMPLIFICADO (WINDOWS)
// --------------------------------------
function upload_file_simple($file, $allowed_ext = ['pdf','jpg','jpeg','png','doc','docx'], $output_name = null){

    global $UPLOADS_DIR;

    // Comprobar si existe carpeta uploads
    if(!is_dir($UPLOADS_DIR)){
        mkdir($UPLOADS_DIR, 0777, true); // En Windows solo crea carpeta
    }

    // Si no se selecciona archivo
    if(!isset($file) || $file['error'] !== UPLOAD_ERR_OK){
        throw new Exception('No se seleccionó archivo o hubo un error en la subida');
    }

    // Obtener extensión
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if(!in_array($ext, $allowed_ext)){
        throw new Exception("Extensión no permitida ($ext)");
    }

    // Si el usuario no definió nombre nuevo, use el original con timestamp
    if($output_name === null){
        $output_name = time() . "_" . basename($file['name']);
    } else {
        $output_name = $output_name . "." . $ext;
    }

    $destino = rtrim($UPLOADS_DIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $output_name;

    // Mover archivo
    if(move_uploaded_file($file['tmp_name'], $destino)){
        return $output_name;
    } else {
        throw new Exception('No se pudo mover el archivo');
    }
}



// --------------------------------------
// FUNCIONES ÚTILES
// --------------------------------------
function limpiar($str){
    global $conn;
    return mysqli_real_escape_string($conn, $str);
}

function redirect($url){
    header("Location: $url");
    exit;
}

// Enviar correo usando PHPMailer (para Hostinger) o mail() como fallback
function send_mail_simple($to, $subject, $message, $headers = "From: no-reply@example.com\r\n"){
    $ok = false;

    // Intentar con PHPMailer si está disponible (para producción en Hostinger)
    if(file_exists(__DIR__ . '/../vendor/autoload.php')){
        require_once __DIR__ . '/../vendor/autoload.php';
        require_once __DIR__ . '/mail_config.php';
        
        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            
            // Configuración SMTP
            $mail->isSMTP();
            $mail->Host = SMTP_HOST;
            $mail->SMTPAuth = true;
            $mail->Username = SMTP_USERNAME;
            $mail->Password = SMTP_PASSWORD;
            $mail->SMTPSecure = SMTP_SECURE;
            $mail->Port = SMTP_PORT;
            $mail->CharSet = 'UTF-8';
            
            // Remitente y destinatario
            $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
            $mail->addAddress($to);
            
            // Contenido
            $mail->isHTML(false);
            $mail->Subject = $subject;
            $mail->Body = $message;
            
            $mail->send();
            $ok = true;
        } catch (Exception $e) {
            // Si falla PHPMailer, intentar con mail()
            $ok = false;
        }
    }
    
    // Fallback: usar mail() nativo (para desarrollo local)
    if(!$ok && function_exists('mail')){
        $ok = @mail($to, $subject, $message, $headers);
    }

    // Si todo falló, guardar en log
    if(!$ok){
        $logdir = __DIR__ . '/../logs';
        if(!is_dir($logdir)) mkdir($logdir, 0777, true);
        $line = date('Y-m-d H:i:s') . " | TO: $to | SUBJ: $subject\n" . $message . "\n---\n";
        file_put_contents($logdir . '/mail.log', $line, FILE_APPEND);
    }

    return $ok;
}
?>
