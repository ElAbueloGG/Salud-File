<?php
$conn = mysqli_connect("localhost","root","","sistema");

if(!$conn){
    die("Error de conexión");
}
?>
