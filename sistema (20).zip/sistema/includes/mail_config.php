<?php
// CONFIGURACIÓN DE CORREO PARA HOSTINGER
// ---------------------------------------

// Datos SMTP de Hostinger
define('SMTP_HOST', 'smtp.hostinger.com');  // o smtp.tu-dominio.com
define('SMTP_PORT', 465);  // 465 para SSL, 587 para TLS
define('SMTP_SECURE', 'ssl');  // 'ssl' o 'tls'
define('SMTP_USERNAME', 'no-reply@tudominio.com');  // Tu correo de Hostinger
define('SMTP_PASSWORD', 'tu_contraseña_aqui');  // Contraseña del correo
define('SMTP_FROM_EMAIL', 'no-reply@tudominio.com');
define('SMTP_FROM_NAME', 'Sistema SALUD-FILE');

// Para instalar PHPMailer:
// composer require phpmailer/phpmailer
?>
