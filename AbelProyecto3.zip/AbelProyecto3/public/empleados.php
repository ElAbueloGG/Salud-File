<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Solo staff (admin o empleado) puede ver esta página
if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff'){
        header('Location: login.php');
        exit;
}
?>

<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="d-flex mb-4 align-items-center">
    <div>
        <h2 class="m-0" style="font-weight: 600; color: var(--primary-blue);">Gestión de Empleados</h2>
        <p class="text-muted mb-0 mt-1" style="font-size: 0.9375rem;">Administra y consulta la información del personal</p>
    </div>
    <a class="btn btn-secondary ms-auto" href="dashboard.php">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem;">
            <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
        </svg>
        Volver
    </a>
</div>

<div class="row g-4">
    <div class="col-lg-5">
        <div class="card alta-bloque">
            <div class="card-body">
                <h3 class="card-title">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem; vertical-align: middle;">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>
                    </svg>
                    Registrar empleado
                </h3>
                <?php if(isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 1): ?>
                <form id="formAddEmp">
                    <div class="mb-2">
                        <label class="form-label">Nombre</label>
                        <input class="form-control" name="nombre" placeholder="Nombre" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Puesto</label>
                        <input class="form-control" name="puesto" placeholder="Puesto">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Teléfono</label>
                        <input class="form-control" name="telefono" placeholder="Teléfono">
                    </div>
                    <div id="msgEmpArea"></div>
                    <div class="mb-2">
                        <label class="form-label">Email</label>
                        <input class="form-control" name="email" type="email" placeholder="email@dominio.com">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Contraseña</label>
                        <input class="form-control" name="password" type="password" placeholder="Contraseña (solo admin)">
                    </div>
                    <div class="d-grid">
                        <button class="btn btn-primary">Guardar</button>
                    </div>
                </form>
                <div id="msgEmp" class="mt-3"></div>
                <?php else: ?>
                <div class="alert alert-info">Solo el administrador puede dar de alta empleados.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card consulta-bloque">
            <div class="card-body">
                <div class="d-flex mb-3 align-items-center">
                    <h3 class="card-title m-0">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem; vertical-align: middle;">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>
                        </svg>
                        Empleados registrados
                    </h3>
                    <div class="ms-auto d-flex align-items-center gap-2">
                        <div class="mostrar-inactivos-toggle">
                            <svg width="18" height="18" fill="none" viewBox="0 0 24 24" class="mostrar-inactivos-icon">
                                <circle id="iconCircle" cx="12" cy="12" r="10" fill="#ef4444"/>
                            </svg>
                            <label class="form-label mb-0 mostrar-inactivos-label" for="toggleInactivosEmp" style="cursor: pointer;">Mostrar inactivos</label>
                            <input class="form-check-input" type="checkbox" id="toggleInactivosEmp" style="cursor: pointer;">
                        </div>
                    </div>
                </div>
                <div id="listaEmpleados">Cargando...</div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
function cargarEmpleados(){
    let f = new FormData();
    f.append('accion','listar');
    const showInactive = document.getElementById('toggleInactivosEmp') && document.getElementById('toggleInactivosEmp').checked;
    if(showInactive) f.append('inactivos','1');
        enviarAjax('empleados_ajax.php', f, function(resp){
                try{
                    console.log('cargarEmpleados response:', resp);
                    document.getElementById('listaEmpleados').innerHTML = resp;
                    if(window.jQuery && $.fn.dataTable){
                        // Destroy existing table(s) if present and reinitialize to avoid "Cannot reinitialise" warning
                        try{
                            if($.fn.dataTable.isDataTable('.datatable')){
                                $('.datatable').DataTable().clear().destroy();
                            }
                        }catch(e){ console.warn('DataTable destroy error', e); }
                        try{
                            $('.datatable').DataTable({
                                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                                     '<"row"<"col-sm-12"B>>' +
                                     '<"row"<"col-sm-12"tr>>' +
                                     '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                                buttons: [
                                    { extend: 'copy', text: 'Copiar', className: 'buttons-copy' },
                                    { extend: 'excel', text: 'Excel', className: 'buttons-excel', title: 'SALUD-FILE - Empleados' },
                                    { 
                                        extend: 'pdf', 
                                        text: 'PDF', 
                                        className: 'buttons-pdf',
                                        title: 'SALUD-FILE - Empleados',
                                        orientation: 'landscape',
                                        pageSize: 'A4',
                                        exportOptions: {
                                            columns: ':visible',
                                            stripHtml: true
                                        },
                                        customize: function(doc) {
                                            doc.pageMargins = [40, 100, 40, 50];
                                            
                                            // Header minimalista y elegante
                                            doc.header = function(currentPage, pageCount) {
                                                return {
                                                    margin: [40, 25, 40, 0],
                                                    columns: [
                                                        {
                                                            width: 'auto',
                                                            text: 'SaludFile',
                                                            fontSize: 20,
                                                            bold: true,
                                                            color: '#155DFC'
                                                        },
                                                        {
                                                            width: '*',
                                                            text: 'Empleados',
                                                            fontSize: 20,
                                                            color: '#64748b',
                                                            alignment: 'left',
                                                            margin: [8, 0, 0, 0]
                                                        }
                                                    ]
                                                };
                                            };
                                            
                                            // Footer minimalista
                                            doc.footer = function(currentPage, pageCount) {
                                                return {
                                                    margin: [40, 15, 40, 0],
                                                    columns: [
                                                        { 
                                                            text: new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' }), 
                                                            fontSize: 8, 
                                                            color: '#94a3b8' 
                                                        },
                                                        { 
                                                            text: currentPage + ' / ' + pageCount, 
                                                            alignment: 'right', 
                                                            fontSize: 8, 
                                                            color: '#94a3b8' 
                                                        }
                                                    ]
                                                };
                                            };
                                            
                                            // Estilos de tabla minimalistas
                                            doc.defaultStyle = {
                                                fontSize: 9
                                            };
                                            
                                            doc.styles.tableHeader = {
                                                fontSize: 9,
                                                bold: true,
                                                fillColor: '#f8fafc',
                                                color: '#1e293b',
                                                alignment: 'left'
                                            };
                                            
                                            // Configuración de tabla
                                            if(doc.content[0] && doc.content[0].table) {
                                                var table = doc.content[0].table;
                                                table.widths = Array(table.body[0].length).fill('auto');
                                                table.layout = {
                                                    hLineWidth: function(i, node) { 
                                                        return (i === 1) ? 1.5 : 0.5;
                                                    },
                                                    vLineWidth: function(i) { return 0; },
                                                    hLineColor: function(i, node) { 
                                                        return (i === 1) ? '#155DFC' : '#e2e8f0';
                                                    },
                                                    fillColor: function(i) { 
                                                        return (i === 0) ? '#f8fafc' : (i % 2 === 0) ? '#fafbfc' : null;
                                                    },
                                                    paddingLeft: function(i) { return i === 0 ? 0 : 8; },
                                                    paddingRight: function(i, node) { return (i === node.table.widths.length - 1) ? 0 : 8; },
                                                    paddingTop: function() { return 8; },
                                                    paddingBottom: function() { return 8; }
                                                };
                                            }
                                        }
                                    },
                                    { extend: 'print', text: 'Imprimir', className: 'buttons-print', title: 'SALUD-FILE - Empleados' }
                                ],
                                responsive: true,
                                pageLength: 10,
                                lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
                                language: { 
                                    url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
                                    buttons: {
                                        copy: 'Copiar',
                                        copyTitle: 'Copiado',
                                        copySuccess: { _: '%d filas copiadas', 1: '1 fila copiada' }
                                    }
                                },
                                order: [[0, 'desc']]
                            });
                        }catch(e){ console.error('DataTable init error', e); }
                    }
                }catch(ex){
                    console.error('Error processing cargarEmpleados response', ex);
                }
        });
}
cargarEmpleados();

// recargar al cambiar el checkbox
$('#toggleInactivosEmp').on('change', function(){ cargarEmpleados(); });

$('#formAddEmp').on('submit', function(e){
        e.preventDefault();
        let f = new FormData(this);
        f.append('accion','agregar');
        enviarAjax('empleados_ajax.php', f, function(resp){
                let lower = (resp||'').toLowerCase();
                if(lower.includes('ya existe') || lower.includes('correo inválido') || lower.includes('error:')){
                    Swal.fire({icon:'error', title:'Error', text: resp});
                } else {
                    Swal.fire({icon:'success', title:'Hecho', text: resp});
                    document.getElementById('formAddEmp').reset();
                    cargarEmpleados();
                }
        });
});

function verEditarEmp(id){
        let f = new FormData(); f.append('accion','ver'); f.append('id', id);
        enviarAjax('empleados_ajax.php', f, function(resp){ document.getElementById('msgEmp').innerHTML = resp; });
}

function guardarEdicionEmp(id){
        let nombre = document.getElementById('edit_nombre').value;
        let puesto  = document.getElementById('edit_puesto').value;
        let telefono= document.getElementById('edit_telefono').value;
        let email = document.getElementById('edit_email') ? document.getElementById('edit_email').value : '';
        let f = new FormData();
        f.append('accion','editar'); f.append('id', id);
        f.append('nombre', nombre); f.append('puesto', puesto); f.append('telefono', telefono); f.append('email', email);
        // append password if present in edit form (visible only to admin)
        let passEl = document.getElementById('edit_password');
        if(passEl){
            // include even if empty so backend can decide; or include only when non-empty to avoid overwrite
            let passVal = passEl.value || '';
            if(passVal !== '') f.append('password', passVal);
        }
        enviarAjax('empleados_ajax.php', f, function(resp){ 
            let lower = (resp||'').toLowerCase();
            if(lower.includes('ya existe') || lower.includes('correo inválido') || lower.includes('no tiene permiso') || lower.includes('no tiene')){
                Swal.fire({icon:'error', title:'Error', text: resp});
            } else {
                Swal.fire({icon:'success', title:'Hecho', text: resp});
                cargarEmpleados();
                document.getElementById('msgEmp').innerHTML = '';
            }
        });
}

function eliminarEmpleado(id){
    // perform soft-delete (admin only) — confirm then call endpoint
    Swal.fire({title:'Confirmar', text:'¿Dar de baja este empleado?', icon:'warning', showCancelButton:true}).then((res)=>{
        if(res.isConfirmed){
            let f = new FormData(); f.append('accion','eliminar'); f.append('id', id);
                        enviarAjax('empleados_ajax.php', f, function(resp){ Swal.fire({icon:'success', title:'Hecho', text:resp}); cargarEmpleados(); });
        }
    });
}

function activarEmpleado(id){
    Swal.fire({title:'Confirmar', text:'¿Reactivar este empleado?', icon:'question', showCancelButton:true}).then((res)=>{
        if(res.isConfirmed){
        let f = new FormData(); f.append('accion','activar'); f.append('id', id);
                enviarAjax('empleados_ajax.php', f, function(resp){ Swal.fire({icon:'success', title:'Hecho', text:resp}); cargarEmpleados(); });
        }
    });
}

// Color dinámico para el icono de mostrar inactivos
document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('toggleInactivosEmp');
    const iconCircle = document.getElementById('iconCircle');
    function updateIconColor() {
        if (toggle && iconCircle) {
            iconCircle.setAttribute('fill', toggle.checked ? '#10b981' : '#ef4444');
        }
    }
    if (toggle && iconCircle) {
        updateIconColor();
        toggle.addEventListener('change', updateIconColor);
    }
});
</script>
