<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if(!isset($_SESSION['user_type']) && !isset($_SESSION['usuario']) && !isset($_SESSION['cliente_id'])){
    echo "Acceso denegado";
    exit;
}
require "../includes/db.php";
require "../includes/functions.php"; // upload_file_simple

$user_type = $_SESSION['user_type'] ?? (isset($_SESSION['cliente_id'])? 'cliente' : (isset($_SESSION['usuario'])? 'staff' : null));
$user_id = $_SESSION['user_id'] ?? ($_SESSION['cliente_id'] ?? null);
$rol_id = $_SESSION['rol_id'] ?? null;

$accion = filter_input(INPUT_POST,'accion',FILTER_SANITIZE_STRING) ?? '';

if($accion == 'listar'){
    if($user_type === 'cliente'){
            $q = mysqli_query($conn, "SELECT p.*, c.nombre as cliente FROM pagos p JOIN clientes c ON p.cliente_id=c.id WHERE p.cliente_id={$user_id} ORDER BY p.id DESC");
    } else {
            $q = mysqli_query($conn, "SELECT p.*, c.nombre as cliente FROM pagos p JOIN clientes c ON p.cliente_id=c.id ORDER BY p.id DESC");
    }
    echo "<table class='table table-striped datatable' style='width:100%'><thead><tr><th>ID</th><th>Cliente</th><th>Monto</th><th>Referencia</th><th>Motivo</th><th>Comprobante</th><th>Fecha</th><th>Acción</th></tr></thead><tbody>";
    while($r = mysqli_fetch_assoc($q)){
        $id = $r['id'];
        $cli = htmlspecialchars($r['cliente']);
        $monto = htmlspecialchars($r['monto']);
        $ref = htmlspecialchars($r['referencia']);
            // description/motivo field may be named 'descripcion' or 'motivo' depending on schema; fall back safely
            $mot = htmlspecialchars($r['descripcion'] ?? ($r['motivo'] ?? ''));
        $comp = htmlspecialchars($r['comprobante']);
        $fecha = htmlspecialchars($r['fecha']);
        $link = $comp ? ("../uploads/".$comp) : '';
        $is_owner = ($user_type === 'cliente' && $r['cliente_id'] == $user_id);
        $is_admin = ($rol_id == 1);
        $actions = '';
        if($is_admin || $is_owner){
            $actions = "<button class='btn btn-sm btn-danger me-1' onclick='eliminarPago({$id})'>Eliminar</button>";
        }
        // admin or owner can edit
        if($is_admin || $is_owner){
            $actions = "<button class='btn btn-sm btn-primary me-1' onclick='verEditarPago({$id})'>Editar</button>" . $actions;
        }
        // Voucher / imprimir (disponible para staff y cliente propietario)
        $actions .= "<button class='btn btn-sm btn-info me-1' onclick=\"abrirVoucher({$id},false)\">Voucher</button>";
        $actions .= "<button class='btn btn-sm btn-secondary me-1' onclick=\"abrirVoucher({$id},true)\">Imprimir/PDF</button>";
                // render row (inside the while loop)
                echo "<tr>
                                <td>{$id}</td>
                                <td>{$cli}</td>
                                <td>{$monto}</td>
                                <td>{$ref}</td>
                                <td>{$mot}</td>
                                <td>".($comp? "<a class='btn btn-sm btn-link' href='{$link}' target='_blank'>Ver</a>":"-")."</td>
                                <td>{$fecha}</td>
                                <td>{$actions}</td>
                            </tr>";
        }
    echo "</tbody></table>";
    exit;
}


// VER pago para editar
if($accion == 'ver'){
    $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
    $q = mysqli_query($conn, "SELECT p.*, c.nombre as cliente FROM pagos p JOIN clientes c ON p.cliente_id=c.id WHERE p.id=$id LIMIT 1");
    $p = mysqli_fetch_assoc($q);
    if(!$p){ echo "Pago no encontrado"; exit; }

    $is_owner = ($user_type === 'cliente' && $p['cliente_id'] == $user_id);
    $is_admin = ($rol_id == 1);
    if(!$is_admin && !$is_owner){ echo "No autorizado"; exit; }

    // cliente select for admin
    $cliente_select = '';
    if($is_admin){
        $cliente_select = "<div class='mb-2'><label class='form-label'>Cliente</label><select id='edit_cliente_id' class='form-select'>";
        $col = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'status'");
        $has_status = ($col && mysqli_num_rows($col)>0);
        if($has_status) $cres = mysqli_query($conn, "SELECT id,nombre FROM clientes WHERE status=1 ORDER BY nombre");
        else $cres = mysqli_query($conn, "SELECT id,nombre FROM clientes ORDER BY nombre");
        while($cc = mysqli_fetch_assoc($cres)){
            $sel = ($cc['id'] == $p['cliente_id'])? 'selected':'';
            $cliente_select .= "<option value='".$cc['id']."' $sel>".htmlspecialchars($cc['nombre'])."</option>";
        }
        $cliente_select .= "</select></div>";
    }

    $comp = htmlspecialchars($p['comprobante']);
    $link = $comp ? "../uploads/".$comp : '';
    ?>
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Editar pago</h5>
            <?php echo $cliente_select; ?>
            <div class="mb-2"><label class="form-label">Monto</label><input id="edit_monto" class="form-control" value="<?=htmlspecialchars($p['monto'])?>"></div>
            <div class="mb-2"><label class="form-label">Referencia</label><input id="edit_referencia" class="form-control" value="<?=htmlspecialchars($p['referencia'])?>"></div>
            <div class="mb-2"><label class="form-label">Motivo</label><input id="edit_motivo" class="form-control" value="<?=htmlspecialchars($p['descripcion'] ?? $p['motivo'] ?? '')?>"></div>
            <div class="mb-2"><label class="form-label">Comprobante (si subes uno nuevo reemplazará el anterior)</label><input id="edit_comprobante" type="file" class="form-control"></div>
            <?php if($link): ?><div class="mt-2"><a href="<?=$link?>" target="_blank" class="btn btn-sm btn-link">Ver comprobante actual</a></div><?php endif; ?>
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <button class="btn btn-primary" onclick="guardarEdicionPago(<?=$p['id']?>)">Guardar cambios</button>
                <button class="btn btn-secondary" onclick="document.getElementById('msgPago').innerHTML=''">Cancelar</button>
            </div>
        </div>
    </div>
    <?php
    exit;
}


// GUARDAR edición pago
if($accion == 'editar'){
    $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
    $monto = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'monto',FILTER_UNSAFE_RAW) ?? '0');
    $referencia = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'referencia',FILTER_UNSAFE_RAW) ?? '');
    $motivo = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'motivo',FILTER_UNSAFE_RAW) ?? '');
    $cliente_id = null;
    if(isset($_POST['cliente_id'])) $cliente_id = (int)$_POST['cliente_id'];

    $q = mysqli_query($conn, "SELECT * FROM pagos WHERE id=$id LIMIT 1");
    $row = mysqli_fetch_assoc($q);
    if(!$row){ echo "Pago no encontrado"; exit; }
    $is_owner = ($user_type === 'cliente' && $row['cliente_id'] == $user_id);
    $is_admin = ($rol_id == 1);
    if(!$is_admin && !$is_owner){ echo "No autorizado"; exit; }

    if($is_admin && $cliente_id) $new_cliente = $cliente_id; else $new_cliente = $row['cliente_id'];

    $new_comp = $row['comprobante'];
    if(isset($_FILES['comprobante']) && $_FILES['comprobante']['error'] === UPLOAD_ERR_OK){
        try{
            global $ALLOWED_PAGOS;
            $uploaded = upload_file_simple($_FILES['comprobante'], $ALLOWED_PAGOS);
            if($row['comprobante']) @unlink(__DIR__ . '/../uploads/' . $row['comprobante']);
            $new_comp = $uploaded;
        } catch(Exception $e){ echo "Error subiendo comprobante: ".$e->getMessage(); exit; }
    }

    $esc_comp = mysqli_real_escape_string($conn, $new_comp);
    mysqli_query($conn, "UPDATE pagos SET cliente_id=$new_cliente, monto='$monto', referencia='$referencia', descripcion='$motivo', comprobante='$esc_comp' WHERE id=$id");
    echo "Cambios guardados";
    exit;
}

    if($accion == 'registrar'){
    // cliente_id may be provided by staff; clients can only register for themselves
    if($user_type === 'cliente'){
        $cliente_id = (int)$user_id;
    } else {
        $cliente_id = (int)(filter_input(INPUT_POST,'cliente_id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
    }
    $monto = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'monto',FILTER_UNSAFE_RAW) ?? '0');
    $referencia = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'referencia',FILTER_UNSAFE_RAW) ?? '');
    $motivo = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'motivo',FILTER_UNSAFE_RAW) ?? '');

        $comprobante_name = '';
        if(isset($_FILES['comprobante']) && $_FILES['comprobante']['error'] === UPLOAD_ERR_OK){
            try {
                global $ALLOWED_PAGOS;
                $comprobante_name = upload_file_simple($_FILES['comprobante'], $ALLOWED_PAGOS);
            } catch(Exception $e){
                echo "Error subiendo comprobante: " . $e->getMessage();
                exit;
            }
        }

        // Insert; don't assume columns beyond the standard set
        $esc_comp = mysqli_real_escape_string($conn, $comprobante_name);
        $sql = "INSERT INTO pagos (cliente_id, monto, referencia, descripcion, comprobante) VALUES ($cliente_id, '$monto', '$referencia', '$motivo', '$esc_comp')";
        if(mysqli_query($conn, $sql)){
            echo "Pago registrado";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
        exit;
}

if($accion == 'eliminar'){
    $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
    if(!$id){ echo "ID inválido"; exit; }
    $r = mysqli_query($conn, "SELECT id, comprobante, cliente_id FROM pagos WHERE id=$id LIMIT 1");
    if($row = mysqli_fetch_assoc($r)){
        $is_owner = ($user_type === 'cliente' && $row['cliente_id'] == $user_id);
        $is_admin = ($rol_id == 1);
        if(!$is_admin && !$is_owner){ echo "No autorizado"; exit; }
        $comp = $row['comprobante'];
        if($comp) @unlink(__DIR__ . '/../uploads/' . $comp);
        mysqli_query($conn, "DELETE FROM pagos WHERE id=$id");
        echo "Pago eliminado";
    } else {
        echo "Pago no encontrado";
    }
    exit;
}
