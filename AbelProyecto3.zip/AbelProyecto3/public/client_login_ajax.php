<?php
session_start();
require __DIR__ . '/../includes/db.php';

$email = filter_input(INPUT_POST,'email',FILTER_VALIDATE_EMAIL);
$password = filter_input(INPUT_POST,'password',FILTER_UNSAFE_RAW);

if(!$email || !$password){
    echo "Faltan datos";
    exit;
}

// Passwords in DB may be stored hashed. We'll support plain or hashed (bcrypt) entries.
$sql = sprintf("SELECT id, nombre, password, status FROM clientes WHERE email='%s' LIMIT 1", mysqli_real_escape_string($conn,$email));
$res = mysqli_query($conn, $sql);
if(!$res || mysqli_num_rows($res) == 0){
    echo "Credenciales inválidas";
    exit;
}
$row = mysqli_fetch_assoc($res);
$dbpass = $row['password'];
// if status column exists and account is inactive, block login
if(isset($row['status']) && (int)$row['status'] === 0){
    echo "Cuenta desactivada";
    exit;
}

$ok = false;
if(!$dbpass){
    // no password set
    echo "No hay contraseña para esta cuenta. Contacta al administrador.";
    exit;
}

// If password stored is bcrypt (starts with $2y$ or $2a$), verify with password_verify
if(strpos($dbpass, '$2y$') === 0 || strpos($dbpass, '$2a$') === 0){
    if(password_verify($password, $dbpass)) $ok = true;
} else {
    // fallback plain compare
    if($password === $dbpass) $ok = true;
}

if($ok){
    $_SESSION['cliente_id'] = $row['id'];
    $_SESSION['cliente_nombre'] = $row['nombre'];
    echo "OK";
} else {
    echo "Credenciales inválidas";
}
