<?php
session_start();
require __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$nombre = mysqli_real_escape_string($conn, trim($_POST['nombre'] ?? ''));
$telefono = mysqli_real_escape_string($conn, trim($_POST['telefono'] ?? ''));
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$direccion = mysqli_real_escape_string($conn, trim($_POST['direccion'] ?? ''));

if(!$nombre || !$email || !$password){
    echo "Faltan datos obligatorios";
    exit;
}

if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    echo "Correo inválido";
    exit;
}

if(strlen($password) < 6){
    echo "La contraseña debe tener al menos 6 caracteres";
    exit;
}

// comprobar email único (y que la columna exista)
$cols = [];
$r = mysqli_query($conn, "SHOW COLUMNS FROM clientes");
while($c = mysqli_fetch_assoc($r)){
    $cols[] = $c['Field'];
}
if(!in_array('email', $cols) || !in_array('password', $cols)){
    echo "La tabla 'clientes' no tiene las columnas 'email' y/o 'password'. Ejecuta el script de migración en scripts/add_client_auth.php";
    exit;
}

$esc_email = mysqli_real_escape_string($conn,$email);
$check = mysqli_query($conn, "SELECT id FROM clientes WHERE email='$esc_email' LIMIT 1");
if($check && mysqli_num_rows($check) > 0){
    echo "Ya existe una cuenta con ese correo";
    exit;
}

// Nota: según petición, almacenamos la contraseña en texto plano (no recomendado en producción)
$raw_pass = mysqli_real_escape_string($conn, $password);

// Si hay usuario en sesión (staff), registrar created_by
$created_by = 'NULL';
if(isset($_SESSION['user_type']) && $_SESSION['user_type']==='staff' && isset($_SESSION['user_id'])){
    $created_by = (int)$_SESSION['user_id'];
}

$sql = "INSERT INTO clientes (nombre, telefono, email, password, direccion" . (is_numeric($created_by) ? ", created_by" : "") . ") VALUES ('". $nombre ."', '". $telefono ."', '". $esc_email ."', '". $raw_pass ."', '". $direccion ."'" . (is_numeric($created_by) ? ", $created_by" : "") . ")";
if(mysqli_query($conn, $sql)){
    $id = mysqli_insert_id($conn);
    $_SESSION['cliente_id'] = $id;
    $_SESSION['cliente_nombre'] = $nombre;

    // enviar correo de notificación (intentar)
    $subject = "Registro en Sistema";
    $message = "Hola $nombre,\n\nSu cuenta ha sido registrada en el sistema.\nUsuario: $esc_email\n";
    send_mail_simple($esc_email, $subject, $message);

    echo "OK";
} else {
    echo "Error al crear cuenta: " . mysqli_error($conn);
}
