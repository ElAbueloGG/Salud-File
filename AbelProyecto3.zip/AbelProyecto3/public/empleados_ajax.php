<?php
if (session_status() === PHP_SESSION_NONE) session_start();

// require either legacy user or normalized session
if (!((isset($_SESSION["usuario"])) || (isset($_SESSION['user_type']) && isset($_SESSION['user_id'])))){
    header("Location: index.php");
    exit;
}

require "../includes/db.php";

$accion = $_POST['accion'] ?? '';

// determine requester role
$is_admin = (isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 1);
$is_empleado = (isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 2);
$user_id = $_SESSION['user_id'] ?? null;
// empleado-specific session id when logging in from `empleados` table
$empleado_session = $_SESSION['empleado_id'] ?? null;

// helper: check if a column exists in 'empleados'
function empleados_has_col($conn, $colname){
    $res = mysqli_query($conn, "SHOW COLUMNS FROM empleados LIKE '".mysqli_real_escape_string($conn,$colname)."'");
    return ($res && mysqli_num_rows($res) > 0);
}

if($accion == 'listar'){
    // check for status column
    $has_status = empleados_has_col($conn, 'status');
    $show_inactivos = isset($_POST['inactivos']) && $_POST['inactivos'] == '1';
    if($has_status){
        if($show_inactivos){
            $q = mysqli_query($conn, "SELECT * FROM empleados WHERE status=0 ORDER BY id DESC");
        } else {
            $q = mysqli_query($conn, "SELECT * FROM empleados WHERE status=1 ORDER BY id DESC");
        }
    } else {
        $q = mysqli_query($conn, "SELECT * FROM empleados ORDER BY id DESC");
    }
    $html = "<table class='table table-striped datatable' style='width:100%'>";
    $html .= "<thead><tr><th>ID</th><th>Nombre</th><th>Puesto</th><th>Teléfono</th><th>Email</th><th>Acciones</th></tr></thead><tbody>";
    while($r = mysqli_fetch_assoc($q)){
        $id = (int)$r['id'];
        $nombre = htmlspecialchars($r['nombre'] ?? '');
        $puesto = htmlspecialchars($r['puesto'] ?? '');
        $tel = htmlspecialchars($r['telefono'] ?? '');
        $email = htmlspecialchars($r['email'] ?? '');

        $usuario_linked = null;
        if(empleados_has_col($conn, 'usuario_id')){
            $usuario_linked = isset($r['usuario_id']) ? (int)$r['usuario_id'] : null;
        }

        $actions = '';
        // determine active status for row
        $is_active = true;
        if($has_status){
            $is_active = ((int)($r['status'] ?? 1) === 1);
        }
        if($is_admin){
            if($is_active){
                $actions .= "<button class='btn btn-sm btn-primary me-1' onclick='verEditarEmp($id)'>Editar</button>";
                $actions .= "<button class='btn btn-sm btn-danger' onclick='eliminarEmpleado($id)'>Dar de baja</button>";
            } else {
                $actions .= "<button class='btn btn-sm btn-success' onclick='activarEmpleado($id)'>Reactivar</button>";
            }
        } elseif($is_empleado){
            $can_edit = false;
            if($usuario_linked && $user_id && $usuario_linked === (int)$user_id) $can_edit = true;
            if($empleado_session && $empleado_session === $id) $can_edit = true;
            if($can_edit){
                $actions .= "<button class='btn btn-sm btn-primary' onclick='verEditarEmp($id)'>Editar mi perfil</button>";
            }
        }

        $row_class = $is_active ? '' : 'table-danger';
        $html .= "<tr class='{$row_class}'><td>{$id}</td><td>{$nombre}</td><td>{$puesto}</td><td>{$tel}</td><td>{$email}</td><td>{$actions}</td></tr>";
    }
    $html .= "</tbody></table>";
    echo $html;
    exit;
}

if($accion == 'agregar'){
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre'] ?? '');
    $puesto  = mysqli_real_escape_string($conn, $_POST['puesto'] ?? '');
    $telefono = mysqli_real_escape_string($conn, $_POST['telefono'] ?? '');
    $email_raw = trim($_POST['email'] ?? '');
    $email = $email_raw ? mysqli_real_escape_string($conn, $email_raw) : '';

    // password only allowed to be set by admin
    $password = '';
    if($is_admin){
        $password = $_POST['password'] ?? '';
    }

    if($email && !filter_var($email, FILTER_VALIDATE_EMAIL)){
        echo "Correo inválido"; exit;
    }

    // check unique email if column exists
    $has_email_col = empleados_has_col($conn, 'email');
    if($has_email_col && $email){
        $chk = mysqli_query($conn, "SELECT id FROM empleados WHERE email='".mysqli_real_escape_string($conn,$email)."' LIMIT 1");
        if($chk && mysqli_num_rows($chk)>0){ echo "Ya existe un empleado con ese correo"; exit; }
    }

    // build insert dynamically
    $has_password_col = empleados_has_col($conn, 'password');

    $fields = [ 'nombre','puesto','telefono' ];
    $values = [ "'".mysqli_real_escape_string($conn,$nombre)."'","'".mysqli_real_escape_string($conn,$puesto)."'","'".mysqli_real_escape_string($conn,$telefono)."'" ];
    if($has_email_col) { $fields[] = 'email'; $values[] = "'".mysqli_real_escape_string($conn,$email)."'"; }
    if($has_password_col && $password){ $fields[] = 'password'; $values[] = "'".mysqli_real_escape_string($conn,$password)."'"; }

    $sql = "INSERT INTO empleados (".implode(',',$fields).") VALUES (".implode(',',$values).")";
    if(mysqli_query($conn, $sql)){
        echo "Empleado agregado correctamente";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
    exit;
}

if($accion == 'eliminar'){
    $id = (int)($_POST['id'] ?? 0);
    if(!$id){ echo "ID inválido"; exit; }
    if(!$is_admin){ echo "No tiene permiso para eliminar empleados"; exit; }

    // prefer soft-delete: set status=0 if column exists, else fallback to DELETE
    if(empleados_has_col($conn, 'status')){
        $deact_by = 'NULL';
        if(isset($_SESSION['user_type']) && $_SESSION['user_type']==='staff' && isset($_SESSION['user_id'])){
            $deact_by = (int)$_SESSION['user_id'];
        }
        $parts = ["status=0", "deactivated_at=NOW()"];
        if(empleados_has_col($conn, 'deactivated_by')){ $parts[] = is_numeric($deact_by)? "deactivated_by=$deact_by" : "deactivated_by=NULL"; }
        $sql = "UPDATE empleados SET " . implode(',', $parts) . " WHERE id=$id";
        if(mysqli_query($conn, $sql)){
            echo "Empleado dado de baja";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        mysqli_query($conn, "DELETE FROM empleados WHERE id=$id");
        echo "Empleado eliminado";
    }
    exit;
}

// reactivar empleado (admin only)
if($accion == 'activar'){
    $id = (int)($_POST['id'] ?? 0);
    if(!$id){ echo "ID inválido"; exit; }
    if(!$is_admin){ echo "No tiene permiso para reactivar empleados"; exit; }

    if(empleados_has_col($conn, 'status')){
        $react_by = 'NULL';
        if(isset($_SESSION['user_type']) && $_SESSION['user_type']==='staff' && isset($_SESSION['user_id'])){
            $react_by = (int)$_SESSION['user_id'];
        }
        $parts = ["status=1", "deactivated_at=NULL"];
        if(empleados_has_col($conn, 'deactivated_by')){ $parts[] = "deactivated_by=NULL"; }
        if(empleados_has_col($conn, 'reactivated_by') && is_numeric($react_by)){ $parts[] = "reactivated_by=$react_by"; }
        $sql = "UPDATE empleados SET " . implode(',', $parts) . " WHERE id=$id";
        if(mysqli_query($conn, $sql)){
            echo "Empleado reactivado";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "La tabla empleados no soporta reactivación (falta columna status)";
    }
    exit;
}

if($accion == 'ver'){
    $id = (int)($_POST['id'] ?? 0);
    $q = mysqli_query($conn, "SELECT * FROM empleados WHERE id=$id LIMIT 1");
    $e = $q ? mysqli_fetch_assoc($q) : null;
    if(!$e){ echo "Empleado no encontrado"; exit; }

    $usuario_linked = null;
    if(empleados_has_col($conn, 'usuario_id')){
        $usuario_linked = isset($e['usuario_id']) ? (int)$e['usuario_id'] : null;
    }

    if(!$is_admin && $is_empleado){
        $can_edit = false;
        if($usuario_linked && $user_id && $usuario_linked === (int)$user_id) $can_edit = true;
        if($empleado_session && $empleado_session === $id) $can_edit = true;
        if(!$can_edit){ echo "No tiene permiso para editar este empleado"; exit; }
    }

    $nombre = htmlspecialchars($e['nombre'] ?? '');
    $puesto = htmlspecialchars($e['puesto'] ?? '');
    $telefono = htmlspecialchars($e['telefono'] ?? '');
    $email = htmlspecialchars($e['email'] ?? '');

    $show_password_field = empleados_has_col($conn, 'password') && $is_admin;

    $out = '';
    $out .= '<div class="card mt-3">';
    $out .= '<div class="card-body">';
    $out .= '<h5 class="card-title">Editar empleado</h5>';
    $out .= '<div class="mb-2"><label class="form-label">Nombre</label><input id="edit_nombre" class="form-control" value="'. $nombre .'"></div>';
    $out .= '<div class="mb-2"><label class="form-label">Puesto</label><input id="edit_puesto" class="form-control" value="'. $puesto .'"></div>';
    $out .= '<div class="mb-2"><label class="form-label">Teléfono</label><input id="edit_telefono" class="form-control" value="'. $telefono .'"></div>';
    $out .= '<div class="mb-2"><label class="form-label">Email</label><input id="edit_email" class="form-control" value="'. $email .'"></div>';
    if($show_password_field){
        $out .= '<div class="mb-2"><label class="form-label">Contraseña (solo admin)</label><input id="edit_password" type="password" class="form-control" placeholder="Nueva contraseña (dejar vacío para no cambiar)"></div>';
    }
    $out .= '<div class="d-grid gap-2 d-md-flex justify-content-md-end">';
    $out .= '<button class="btn btn-primary" onclick="guardarEdicionEmp('.$id.')">Guardar cambios</button>';
    $out .= '<button class="btn btn-secondary" onclick="document.getElementById(\'msgEmp\').innerHTML=\''.'\'">Cancelar</button>';
    $out .= '</div></div></div>';

    echo $out;
    exit;
}

if($accion == 'editar'){
    $id = (int)($_POST['id'] ?? 0);
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre'] ?? '');
    $puesto  = mysqli_real_escape_string($conn, $_POST['puesto'] ?? '');
    $telefono = mysqli_real_escape_string($conn, $_POST['telefono'] ?? '');
    $email_raw = trim($_POST['email'] ?? '');
    $email = $email_raw ? mysqli_real_escape_string($conn, $email_raw) : '';

    if($email && !filter_var($email, FILTER_VALIDATE_EMAIL)){
        echo "Correo inválido"; exit;
    }

    $has_email_col = empleados_has_col($conn, 'email');
    if($has_email_col && $email){
        $chk = mysqli_query($conn, "SELECT id FROM empleados WHERE email='".mysqli_real_escape_string($conn,$email)."' AND id<>$id LIMIT 1");
        if($chk && mysqli_num_rows($chk)>0){ echo "Ya existe un empleado con ese correo"; exit; }
    }

    $usuario_linked = null;
    if(empleados_has_col($conn, 'usuario_id')){
        $q = mysqli_query($conn, "SELECT usuario_id FROM empleados WHERE id=$id LIMIT 1");
        $row = $q ? mysqli_fetch_assoc($q) : null;
        $usuario_linked = $row && isset($row['usuario_id']) ? (int)$row['usuario_id'] : null;
    }

    if($is_admin){
        // ok
    } elseif($is_empleado){
        $can_edit = false;
        if($usuario_linked && $user_id && $usuario_linked === (int)$user_id) $can_edit = true;
        if($empleado_session && $empleado_session === $id) $can_edit = true;
        if(!$can_edit){ echo "No tiene permiso para editar este empleado"; exit; }
    } else {
        echo "No tiene permiso"; exit;
    }

    $sets = [];
    $sets[] = "nombre='".mysqli_real_escape_string($conn,$nombre)."'";
    $sets[] = "puesto='".mysqli_real_escape_string($conn,$puesto)."'";
    $sets[] = "telefono='".mysqli_real_escape_string($conn,$telefono)."'";
    if($has_email_col && $email) $sets[] = "email='".mysqli_real_escape_string($conn,$email)."'";

    $has_password_col = empleados_has_col($conn, 'password');
    if($is_admin && $has_password_col){
        $newpass = $_POST['password'] ?? '';
        if($newpass){
            $sets[] = "password='".mysqli_real_escape_string($conn,$newpass)."'";
        }
    }

    if(count($sets) === 0){ echo "Nada para actualizar"; exit; }

    mysqli_query($conn, "UPDATE empleados SET " . implode(',', $sets) . " WHERE id=$id");
    echo "Cambios guardados";
    exit;
}

// default
echo "Accion no reconocida";
exit;

