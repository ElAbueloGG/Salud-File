<?php
require_once __DIR__ . '/../includes/db.php';
session_start();

// Only admin (rol_id == 1) can access this panel
if(!isset($_SESSION['rol_id']) || intval($_SESSION['rol_id']) !== 1){
    header('Location: login.php');
    exit;
}

function esc($s){ global $conn; return htmlspecialchars($s,ENT_QUOTES,'UTF-8'); }

// Fetch usuarios, empleados, clientes
$usuarios = mysqli_query($conn, "SELECT id,nombre,email,rol_id FROM usuarios ORDER BY id DESC");
$empleados = mysqli_query($conn, "SELECT id,nombre,puesto,telefono,user FROM empleados ORDER BY id DESC");
$clientes = mysqli_query($conn, "SELECT id,nombre,telefono,email FROM clientes ORDER BY id DESC");

?>
<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Panel de Administración</h1>

</div>

<h2>Usuarios</h2>
    <table class="table table-striped datatable" border="1" cellpadding="6" style="width:100%">
        <tr><th>ID</th><th>Nombre</th><th>Email</th><th>Rol ID</th></tr>
        <?php while($u = mysqli_fetch_assoc($usuarios)): ?>
            <tr>
                <td><?php echo esc($u['id']); ?></td>
                <td><?php echo esc($u['nombre']); ?></td>
                <td><?php echo esc($u['email']); ?></td>
                <td><?php echo esc($u['rol_id']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h2 class="mt-4">Empleados</h2>
    <p>Usa esto para crear entradas en `usuarios` desde la tabla `empleados`.</p>
    <p><a href="/sistema/scripts/create_users_from_empleados.php">Previsualizar creación de usuarios</a> — <a href="/sistema/scripts/create_users_from_empleados.php?run=1">Ejecutar creación de usuarios</a></p>
    <table class="table table-striped datatable" border="1" cellpadding="6" style="width:100%">
        <tr><th>ID</th><th>Nombre</th><th>Puesto</th><th>Teléfono</th><th>Usuario</th></tr>
        <?php while($e = mysqli_fetch_assoc($empleados)): ?>
            <tr>
                <td><?php echo esc($e['id']); ?></td>
                <td><?php echo esc($e['nombre']); ?></td>
                <td><?php echo esc($e['puesto']); ?></td>
                <td><?php echo esc($e['telefono']); ?></td>
                <td><?php echo esc($e['user']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h2 class="mt-4">Clientes</h2>
    <table class="table table-striped datatable" border="1" cellpadding="6" style="width:100%">
        <tr><th>ID</th><th>Nombre</th><th>Teléfono</th><th>Email</th></tr>
        <?php while($c = mysqli_fetch_assoc($clientes)): ?>
            <tr>
                <td><?php echo esc($c['id']); ?></td>
                <td><?php echo esc($c['nombre']); ?></td>
                <td><?php echo esc($c['telefono']); ?></td>
                <td><?php echo esc($c['email']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

