<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Sólo el personal (administrador o empleado) debe usar esta página. Los clientes tienen su propia página.
if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff'){
        header('Location: login.php');
        exit;
}
?>

<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Gestión de Documentos</h2>
    <a class="btn btn-secondary" href="dashboard.php">⬅ Volver</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title">Subir documento</h5>
        <form id="formDoc" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-4">
                    <select name="cliente_id" class="form-select" required>
                        <option value="">Selecciona cliente</option>
                        <?php
                        // Comprobar si la columna `status` existe para evitar errores en esquemas antiguos
                        $has_status = false;
                        $col = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'status'");
                        if($col && mysqli_num_rows($col) > 0) $has_status = true;

                        if($has_status){
                            $res = mysqli_query($conn, "SELECT id,nombre FROM clientes WHERE status=1 ORDER BY nombre");
                        } else {
                            $res = mysqli_query($conn, "SELECT id,nombre FROM clientes ORDER BY nombre");
                        }

                        while($c = mysqli_fetch_assoc($res)){
                            echo "<option value=\"{$c['id']}\">".htmlspecialchars($c['nombre'])."</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="tipo" class="form-select" required>
                        <option value="Receta">Receta</option>
                        <option value="Acta de nacimiento">Acta de nacimiento</option>
                        <option value="CURP">CURP</option>
                        <option value="INE">INE</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="file" name="archivo" class="form-control" required>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary">Subir</button>
                </div>
            </div>
        </form>
        <div id="msgDoc" class="mt-2"></div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h5 class="card-title">Documentos subidos</h5>
        <div id="listaDocs">Cargando...</div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
function cargarDocs(){
    let f = new FormData(); f.append('accion','listar');
    enviarAjax('documentos_ajax.php', f, function(resp){
        document.getElementById('listaDocs').innerHTML = resp;
        if(window.jQuery && $.fn.dataTable){
            // Destruir todas las instancias previas de DataTable en la tabla
            $('.datatable').each(function(){
                if ($.fn.dataTable.isDataTable(this)) {
                    $(this).DataTable().clear().destroy();
                }
            });
                $('.datatable').DataTable({
                    dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                         '<"row"<"col-sm-12"B>>' +
                         '<"row"<"col-sm-12"tr>>' +
                         '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                    buttons: [
                        { extend: 'copy', text: 'Copiar', className: 'buttons-copy' },
                        { extend: 'excel', text: 'Excel', className: 'buttons-excel', title: 'SaludFile - Documentos' },
                        { 
                            extend: 'pdf', 
                            text: 'PDF', 
                            className: 'buttons-pdf',
                            title: 'SaludFile - Documentos',
                            orientation: 'landscape',
                            pageSize: 'A4',
                            exportOptions: {
                                columns: ':visible',
                                stripHtml: true
                            },
                            customize: function(doc) {
                                doc.pageMargins = [40, 100, 40, 50];
                                
                                // Header minimalista y elegante
                                doc.header = function(currentPage, pageCount) {
                                    return {
                                        margin: [40, 25, 40, 0],
                                        columns: [
                                            {
                                                width: 'auto',
                                                text: 'SaludFile',
                                                fontSize: 20,
                                                bold: true,
                                                color: '#155DFC'
                                            },
                                            {
                                                width: '*',
                                                text: 'Documentos',
                                                fontSize: 20,
                                                color: '#64748b',
                                                alignment: 'left',
                                                margin: [8, 0, 0, 0]
                                            }
                                        ]
                                    };
                                };
                                
                                // Footer minimalista
                                doc.footer = function(currentPage, pageCount) {
                                    return {
                                        margin: [40, 15, 40, 0],
                                        columns: [
                                            { 
                                                text: new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' }), 
                                                fontSize: 8, 
                                                color: '#94a3b8' 
                                            },
                                            { 
                                                text: currentPage + ' / ' + pageCount, 
                                                alignment: 'right', 
                                                fontSize: 8, 
                                                color: '#94a3b8' 
                                            }
                                        ]
                                    };
                                };
                                
                                // Estilos de tabla minimalistas
                                doc.defaultStyle = {
                                    fontSize: 9
                                };
                                
                                doc.styles.tableHeader = {
                                    fontSize: 9,
                                    bold: true,
                                    fillColor: '#f8fafc',
                                    color: '#1e293b',
                                    alignment: 'left'
                                };
                                
                                // Configuración de tabla
                                if(doc.content[0] && doc.content[0].table) {
                                    var table = doc.content[0].table;
                                    table.widths = Array(table.body[0].length).fill('auto');
                                    table.layout = {
                                        hLineWidth: function(i, node) { 
                                            return (i === 1) ? 1.5 : 0.5;
                                        },
                                        vLineWidth: function(i) { return 0; },
                                        hLineColor: function(i, node) { 
                                            return (i === 1) ? '#155DFC' : '#e2e8f0';
                                        },
                                        fillColor: function(i) { 
                                            return (i === 0) ? '#f8fafc' : (i % 2 === 0) ? '#fafbfc' : null;
                                        },
                                        paddingLeft: function(i) { return i === 0 ? 0 : 8; },
                                        paddingRight: function(i, node) { return (i === node.table.widths.length - 1) ? 0 : 8; },
                                        paddingTop: function() { return 8; },
                                        paddingBottom: function() { return 8; }
                                    };
                                }
                            }
                        },
                        { extend: 'print', text: 'Imprimir', className: 'buttons-print', title: 'SaludFile - Documentos' }
                    ],
                    responsive: true,
                    pageLength: 10,
                    lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
                    language: { 
                        url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
                        buttons: {
                            copy: 'Copiar',
                            copyTitle: 'Copiado',
                            copySuccess: { _: '%d filas copiadas', 1: '1 fila copiada' }
                        }
                    },
                    order: [[0, 'desc']]
                });
        }
    });
}
cargarDocs();

$('#formDoc').on('submit', function(e){
    e.preventDefault();
    let f = new FormData(this);
    f.append('accion','subir');
    enviarAjax('documentos_ajax.php', f, function(resp){
        const lower = (resp||'').toLowerCase();
        if(lower.includes('error') || lower.includes('no autorizado') || lower.includes('ya existe')){
            Swal.fire({icon:'error', title:'Error', text: resp});
        } else {
            Swal.fire({icon:'success', title:'Hecho', text: resp});
            document.getElementById('formDoc').reset();
            cargarDocs();
        }
    });
});

function eliminarDoc(id){
    Swal.fire({title:'Confirmar', text:'¿Eliminar documento?', icon:'warning', showCancelButton:true}).then((r)=>{
        if(r.isConfirmed){
            let f=new FormData(); f.append('accion','eliminar'); f.append('id',id);
            enviarAjax('documentos_ajax.php', f, function(resp){
                const lower = (resp||'').toLowerCase();
                if(lower.includes('error') || lower.includes('no autorizado')){
                    Swal.fire({icon:'error', title:'Error', text: resp});
                } else {
                    Swal.fire({icon:'success', title:'Eliminado', text: resp});
                }
                cargarDocs();
            });
        }
    });
}

function verEditarDoc(id){
    let f = new FormData(); f.append('accion','ver'); f.append('id', id);
    enviarAjax('documentos_ajax.php', f, function(resp){ document.getElementById('msgDoc').innerHTML = resp; });
}

function guardarEdicionDoc(id){
    const tipo = document.getElementById('edit_tipo').value;
    const form = new FormData();
    form.append('accion','editar'); form.append('id', id); form.append('tipo', tipo);
    const clienteSel = document.getElementById('edit_cliente_id');
    if(clienteSel) form.append('cliente_id', clienteSel.value);
    const fileInput = document.getElementById('edit_archivo');
    if(fileInput && fileInput.files && fileInput.files.length) form.append('archivo', fileInput.files[0]);
    enviarAjax('documentos_ajax.php', form, function(resp){
        const lower = (resp||'').toLowerCase();
        if(lower.includes('error') || lower.includes('no autorizado')){
            Swal.fire({icon:'error', title:'Error', text: resp});
        } else {
            Swal.fire({icon:'success', title:'Hecho', text: resp});
            document.getElementById('msgDoc').innerHTML = '';
            cargarDocs();
        }
    });
}
</script>
