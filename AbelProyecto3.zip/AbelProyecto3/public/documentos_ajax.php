<?php
require "../includes/db.php";
$accion = isset($_POST['accion']) ? $_POST['accion'] : '';
if (session_status() === PHP_SESSION_NONE) session_start();
// allow staff (usuario) or cliente
if(!isset($_SESSION['user_type']) && !isset($_SESSION['usuario']) && !isset($_SESSION['cliente_id'])){
    echo "Acceso denegado";
    exit;
}

require "../includes/functions.php"; // para upload_file_simple
// determine user type and id
$user_type = $_SESSION['user_type'] ?? (isset($_SESSION['cliente_id'])? 'cliente' : (isset($_SESSION['usuario'])? 'staff' : null));
$user_id = $_SESSION['user_id'] ?? ($_SESSION['cliente_id'] ?? null);
$rol_id = $_SESSION['rol_id'] ?? null; // 1=Admin,2=Empleado,3=Cliente (if used)
$is_empleado = ($rol_id == 2);

// Leer entradas POST de forma segura
$accion = filter_input(INPUT_POST, 'accion', FILTER_SANITIZE_STRING) ?? '';

if($accion == 'listar'){
    if($user_type === 'cliente'){
        $q = mysqli_query($conn, "SELECT d.*, c.nombre as cliente_nombre FROM documentos d LEFT JOIN clientes c ON d.cliente_id = c.id WHERE d.cliente_id={$user_id} ORDER BY d.id DESC");
    } else {
        $q = mysqli_query($conn, "SELECT d.*, c.nombre as cliente_nombre FROM documentos d LEFT JOIN clientes c ON d.cliente_id = c.id ORDER BY d.id DESC");
    }
    $html = "<table class='table table-striped datatable' style='width:100%'>\n";
    $html .= "<thead><tr><th>ID</th><th>Cliente</th><th>Tipo</th><th>Archivo</th><th>Fecha</th><th>Acciones</th></tr></thead><tbody>";
    while($r = mysqli_fetch_assoc($q)){
        $archivo = htmlspecialchars($r['archivo']);
        $tipo = htmlspecialchars($r['tipo']);
        $fecha = htmlspecialchars($r['fecha']);
        $cliente = htmlspecialchars($r['cliente_nombre'] ?: $r['cliente_id']);
        $id = (int)$r['id'];
        $btns = "<button class='btn btn-sm btn-danger' onclick='eliminarDoc($id)'>Eliminar</button> ";
        if($user_type !== 'cliente'){
            $btns .= "<button class='btn btn-sm btn-primary' onclick='verEditarDoc($id)'>Editar</button> ";
        }
        $html .= "<tr>";
        $html .= "<td>$id</td><td>$cliente</td><td>$tipo</td><td><a href='../uploads/$archivo' target='_blank'>$archivo</a></td><td>$fecha</td><td>$btns</td>";
        $html .= "</tr>";
    }
    $html .= "</tbody></table>";
    echo $html;
    exit;
}

    if($accion == 'subir'){
        $tipo = mysqli_real_escape_string($conn, filter_input(INPUT_POST, 'tipo', FILTER_UNSAFE_RAW) ?? '');
        if($user_type === 'cliente'){
            $cliente_id = (int)$user_id;
        } else {
            $cliente_id = (int)(filter_input(INPUT_POST, 'cliente_id', FILTER_SANITIZE_NUMBER_INT) ?? 0);
        }
        if(!$cliente_id){ echo "Cliente inválido"; exit; }
        $check = mysqli_query($conn, "SELECT id FROM documentos WHERE cliente_id=$cliente_id AND tipo='".mysqli_real_escape_string($conn,$tipo)."' LIMIT 1");
        if(mysqli_num_rows($check) > 0){ echo "Ya existe ese tipo de documento para este cliente"; exit; }
        if(!isset($_FILES['archivo'])){ echo "Archivo no recibido"; exit; }
        try {
            global $ALLOWED_DOCS;
            $name = upload_file_simple($_FILES['archivo'], $ALLOWED_DOCS);
            $name_db = mysqli_real_escape_string($conn, $name);
            mysqli_query($conn, "INSERT INTO documentos (cliente_id, tipo, archivo) VALUES ($cliente_id, '$tipo', '$name_db')");
            // Mensaje solo texto plano
            echo "Archivo subido correctamente";
        } catch (Exception $e){
            echo "Error: " . $e->getMessage();
        }
        exit;
    }

    if($accion == 'ver'){
        $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
        $q = mysqli_query($conn, "SELECT d.*, c.nombre as cliente_nombre FROM documentos d LEFT JOIN clientes c ON d.cliente_id = c.id WHERE d.id=$id LIMIT 1");
        $row = mysqli_fetch_assoc($q);
        if(!$row){ echo "Documento no encontrado"; exit; }
        $tipo = htmlspecialchars($row['tipo']);
        $archivo = htmlspecialchars($row['archivo']);
        $cliente_id = (int)$row['cliente_id'];
        // Obtener lista de clientes (solo para admin mostraremos select)
        $clientes = [];
        $res = mysqli_query($conn, "SELECT id, nombre FROM clientes ORDER BY nombre");
        while($c = mysqli_fetch_assoc($res)){
            $clientes[] = $c;
        }
        // Formulario de edición
        echo "<form id='formEditDoc' enctype='multipart/form-data' onsubmit='event.preventDefault(); guardarEdicionDoc($id);'>";
        if($rol_id == 1){
            // Administrador puede cambiar el cliente
            echo "<div class='mb-2'><label class='form-label'>Cliente</label><select id='edit_cliente_id' class='form-select'>";
            foreach($clientes as $c){
                $sel = ($c['id'] == $cliente_id) ? 'selected' : '';
                $nombre = htmlspecialchars($c['nombre']);
                echo "<option value='{$c['id']}' $sel>$nombre</option>";
            }
            echo "</select></div>";
        } else {
            // Empleado o cliente: mostrar nombre en solo lectura (no enviar campo cliente)
            $cliente_nombre = htmlspecialchars($row['cliente_nombre'] ?: $cliente_id);
            echo "<div class='mb-2'><label class='form-label'>Cliente</label><input type='text' class='form-control' value='$cliente_nombre' readonly></div>";
        }
        echo "<div class='mb-2'><label class='form-label'>Tipo</label><select id='edit_tipo' class='form-select'>";
        $tipos = ['Receta','Acta de nacimiento','CURP','INE'];
        foreach($tipos as $t){
            $sel = ($tipo == $t) ? 'selected' : '';
            echo "<option value='$t' $sel>$t</option>";
        }
        echo "</select></div>";
        echo "<div class='mb-2'><label class='form-label'>Archivo actual</label> <a href='../uploads/$archivo' target='_blank'>$archivo</a></div>";
        echo "<div class='mb-2'><label class='form-label'>Nuevo archivo (opcional)</label><input type='file' id='edit_archivo' class='form-control'></div>";
        echo "<button class='btn btn-primary'>Guardar cambios</button> <button type='button' class='btn btn-secondary' onclick='document.getElementById(\'msgDoc\').innerHTML=\''\';'>Cancelar</button>";
        echo "</form>";
        exit;
    }

    if($accion == 'editar'){
        $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
        $tipo = mysqli_real_escape_string($conn, filter_input(INPUT_POST,'tipo',FILTER_UNSAFE_RAW) ?? '');
        $cliente_id = null;
        if(isset($_POST['cliente_id'])) $cliente_id = (int)$_POST['cliente_id'];
        $q = mysqli_query($conn, "SELECT * FROM documentos WHERE id=$id LIMIT 1");
        $row = mysqli_fetch_assoc($q);
        if(!$row){ echo "Documento no encontrado"; exit; }
        $is_owner = ($user_type === 'cliente' && $row['cliente_id'] == $user_id);
        $is_admin = ($rol_id == 1);
        $is_empleado = ($rol_id == 2);
        if(!$is_admin && !$is_owner && !$is_empleado){ echo "No autorizado"; exit; }
        if($is_admin && $cliente_id) $new_cliente = $cliente_id; else $new_cliente = $row['cliente_id'];
        $new_file = $row['archivo'];
        if(isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK){
            try{
                global $ALLOWED_DOCS;
                $uploaded = upload_file_simple($_FILES['archivo'], $ALLOWED_DOCS);
                if($row['archivo']) @unlink(__DIR__ . '/../uploads/' . $row['archivo']);
                $new_file = $uploaded;
            } catch(Exception $e){ echo "Error subiendo archivo: ".$e->getMessage(); exit; }
        }
        $esc_file = mysqli_real_escape_string($conn, $new_file);
        mysqli_query($conn, "UPDATE documentos SET tipo='".$tipo."', archivo='".$esc_file."', cliente_id=$new_cliente WHERE id=$id");
        echo "Cambios guardados";
        exit;
    }

    if($accion == 'eliminar'){
        $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
        if(!$id){ echo "ID inválido"; exit; }
        $r = mysqli_query($conn, "SELECT id, archivo, cliente_id FROM documentos WHERE id=$id LIMIT 1");
        if($row = mysqli_fetch_assoc($r)){
            $is_owner = ($user_type === 'cliente' && $row['cliente_id'] == $user_id);
            $is_admin = ($rol_id == 1);
            if(!$is_admin && !$is_owner){
                echo "No autorizado"; exit;
            }
            $archivo = $row['archivo'];
            @unlink(__DIR__ . '/../uploads/' . $archivo);
            mysqli_query($conn, "DELETE FROM documentos WHERE id=$id");
            echo "Documento eliminado";
        } else {
            echo "Documento no encontrado";
        }
        exit;
    }



if($accion == 'eliminar'){
    $id = (int)(filter_input(INPUT_POST,'id',FILTER_SANITIZE_NUMBER_INT) ?? 0);
    if(!$id){ echo "ID inválido"; exit; }
    $r = mysqli_query($conn, "SELECT id, archivo, cliente_id FROM documentos WHERE id=$id LIMIT 1");
    if($row = mysqli_fetch_assoc($r)){
        // only admin or owner can delete. employees cannot delete
        $is_owner = ($user_type === 'cliente' && $row['cliente_id'] == $user_id);
        $is_admin = ($rol_id == 1);
        if(!$is_admin && !$is_owner){
            echo "No autorizado"; exit;
        }
        $archivo = $row['archivo'];
        @unlink(__DIR__ . '/../uploads/' . $archivo);
        mysqli_query($conn, "DELETE FROM documentos WHERE id=$id");
        echo "Documento eliminado";
    } else {
        echo "Documento no encontrado";
    }
    exit;
}
