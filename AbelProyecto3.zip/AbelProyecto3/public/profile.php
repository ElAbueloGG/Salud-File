<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Require logged-in user
if(!isset($_SESSION['user_type']) || !isset($_SESSION['user_nombre'])){
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/../includes/header.php';

$profile = ['nombre'=>'','email'=>'','telefono'=>'','puesto'=>'','rango'=>''];
$user_type = $_SESSION['user_type'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;
$cliente_id = $_SESSION['cliente_id'] ?? null;
$empleado_id = $_SESSION['empleado_id'] ?? null;

// Prefer DB values (more reliable) but fall back to session where necessary
if($user_type === 'cliente' && $user_id){
  $q = mysqli_query($conn, "SELECT nombre,email,telefono FROM clientes WHERE id=".(int)$user_id." LIMIT 1");
  if($r = mysqli_fetch_assoc($q)){
    $profile['nombre'] = $r['nombre'] ?? '';
    $profile['email'] = $r['email'] ?? '';
    $profile['telefono'] = $r['telefono'] ?? '';
    // Si tienes un campo rango en clientes, lo puedes mostrar aquí
    if(isset($r['rango'])) $profile['rango'] = $r['rango'];
  }
} else {
  // staff path: try empleados if empleado_id available, else try usuarios
  if(!empty($empleado_id)){
    $q = mysqli_query($conn, "SELECT nombre,email,telefono,puesto FROM empleados WHERE id=".(int)$empleado_id." LIMIT 1");
    if($r = mysqli_fetch_assoc($q)){
      $profile['nombre'] = $r['nombre'] ?? '';
      $profile['email'] = $r['email'] ?? '';
      $profile['telefono'] = $r['telefono'] ?? '';
      $profile['puesto'] = $r['puesto'] ?? '';
    }
  }
  if(empty($profile['nombre']) && !empty($user_id)){
    $q = mysqli_query($conn, "SELECT nombre,email,telefono,rol_id FROM usuarios WHERE id=".(int)$user_id." LIMIT 1");
    if($r = mysqli_fetch_assoc($q)){
      $profile['nombre'] = $r['nombre'] ?? '';
      $profile['email'] = $r['email'] ?? '';
      $profile['telefono'] = $r['telefono'] ?? '';
      // Si tienes tabla roles, puedes mostrar el nombre del rol
      if(isset($r['rol_id'])){
        $rol_id = (int)$r['rol_id'];
        $qr = mysqli_query($conn, "SELECT nombre FROM roles WHERE id=$rol_id LIMIT 1");
        if($rol = mysqli_fetch_assoc($qr)) $profile['rango'] = $rol['nombre'];
      }
    }
  }
}

// Fallback to session values if DB didn't return full info
if(empty($profile['nombre']) && !empty($_SESSION['user_nombre'])) $profile['nombre'] = $_SESSION['user_nombre'];
if(empty($profile['email']) && !empty($_SESSION['user_email'])) $profile['email'] = $_SESSION['user_email'];

?>

<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Perfil de usuario</h4>
          <p class="text-muted">Información visible solo para tu cuenta</p>
          <div class="mb-3"><strong>Nombre:</strong> <?php echo htmlspecialchars($profile['nombre']); ?></div>
          <div class="mb-3"><strong>Correo:</strong> <?php echo htmlspecialchars($profile['email']); ?></div>
          <div class="mb-3"><strong>Teléfono:</strong> <?php echo htmlspecialchars($profile['telefono']); ?></div>
          <?php if(!empty($profile['puesto'])): ?>
            <div class="mb-3"><strong>Puesto:</strong> <?php echo htmlspecialchars($profile['puesto']); ?></div>
          <?php endif; ?>
          <div class="mb-3"><strong>Rango:</strong> <?php
            if($user_type === 'cliente') echo 'Cliente';
            elseif($user_type === 'staff' && isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 1) echo 'Administrador';
            elseif($user_type === 'staff' && isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 2) echo 'Empleado';
            elseif(!empty($profile['rango'])) echo htmlspecialchars($profile['rango']);
            else echo 'Desconocido';
          ?></div>
          <button class="btn btn-outline-primary mt-3" id="btnShowPassModal">¿Quieres cambiar tu contraseña?</button>
          <a href="dashboard.php" class="btn btn-secondary mt-3">Volver</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal fuera del card para evitar problemas de renderizado -->
<div class="modal fade" id="modalPass" tabindex="-1" aria-labelledby="modalPassLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalPassLabel">Actualizar contraseña</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <form id="formCambiarPass">
          <div class="mb-2">
            <label class="form-label">Nueva contraseña</label>
            <input type="password" class="form-control" name="nueva" required minlength="4">
          </div>
          <div class="mb-2">
            <label class="form-label">Confirmar nueva contraseña</label>
            <input type="password" class="form-control" name="confirmar" required minlength="4">
          </div>
          <button class="btn btn-primary" type="submit">Actualizar</button>
          <div id="msgPass" class="mt-2"></div>
        </form>
      </div>
    </div>
  </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function(){
  // Botón para mostrar modal
  document.getElementById('btnShowPassModal').addEventListener('click', function(){
    var modalElement = document.getElementById('modalPass');
    var modal = new bootstrap.Modal(modalElement);
    modal.show();
  });
  
  // Formulario de cambio de contraseña
  document.getElementById('formCambiarPass').addEventListener('submit', function(e){
    e.preventDefault();
    var formData = new FormData(this);
    var formElement = this;
    var msgElement = document.getElementById('msgPass');
    
    // Limpiar mensajes previos
    msgElement.innerHTML = '';
    
    fetch('cambiar_password.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(text => {
      if(text.trim() === 'OK'){
        var modalElement = document.getElementById('modalPass');
        var modal = bootstrap.Modal.getInstance(modalElement);
        
        // Mostrar SweetAlert
        if(window.Swal){
          Swal.fire({
            icon: 'success', 
            title: '¡Contraseña actualizada!', 
            text: 'Tu contraseña se cambió correctamente.',
            confirmButtonColor: '#155DFC',
            allowOutsideClick: false
          }).then(function(){
            // Cerrar modal y limpiar formulario
            if(modal){
              modal.hide();
            }
            formElement.reset();
          });
        } else {
          alert('Tu contraseña se cambió correctamente.');
          if(modal){
            modal.hide();
          }
          formElement.reset();
        }
      } else {
        // Mostrar error en el modal
        msgElement.innerHTML = '<div class="alert alert-danger mt-2" role="alert">' + text + '</div>';
      }
    })
    .catch(error => {
      msgElement.innerHTML = '<div class="alert alert-danger mt-2" role="alert">Error de red. Intenta nuevamente.</div>';
    });
  });
  
  // Limpiar mensajes cuando se cierra el modal
  var modalElement = document.getElementById('modalPass');
  modalElement.addEventListener('hidden.bs.modal', function(){
    document.getElementById('formCambiarPass').reset();
    document.getElementById('msgPass').innerHTML = '';
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
