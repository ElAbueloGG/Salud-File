<?php
// Simple client login page
session_start();
if(isset($_SESSION['cliente_id'])){
    header('Location: client_documentos.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Ingreso cliente</title>
    <script src="../assets/js/ajax.js"></script>
</head>
<body>
<h2>Ingreso clientes</h2>
<form id="clientLoginForm">
    <input type="email" name="email" id="email" placeholder="Email" required><br><br>
    <input type="password" name="password" id="password" placeholder="Contraseña" required><br><br>
    <button>Entrar</button>
</form>
<div id="msg"></div>

<hr>
<h3>¿No tienes cuenta? <a href="#" id="showRegister">Regístrate aquí</a></h3>

<div id="registerBox" style="display:none; border:1px solid #ddd; padding:12px; margin-top:10px; max-width:480px;">
    <h3>Registro de cliente</h3>
    <form id="registerForm">
        <input type="text" name="nombre" id="reg_nombre" placeholder="Nombre completo" required><br><br>
        <input type="text" name="telefono" id="reg_telefono" placeholder="Teléfono"><br><br>
        <input type="email" name="email" id="reg_email" placeholder="Correo electrónico" required><br><br>
        <input type="password" name="password" id="reg_password" placeholder="Contraseña (mín 6 caracteres)" required><br><br>
        <textarea name="direccion" id="reg_direccion" placeholder="Dirección"></textarea><br><br>
        <button>Registrar</button>
        <button type="button" id="cancelRegister">Cancelar</button>
    </form>
    <div id="msgRegister"></div>
</div>

<script>
document.getElementById('clientLoginForm').onsubmit = function(e){
    e.preventDefault();
    let f = new FormData(this);
    fetch('client_login_ajax.php', {method:'POST', body: f})
    .then(r=>r.text()).then(t=>{
        if(t.trim() === 'OK'){
            window.location.href = 'client_documentos.php';
        } else {
            if(t.trim() === 'Cuenta desactivada'){
                if(window.Swal){
                    Swal.fire({icon:'error', title:'Cuenta desactivada', text:'Tu cuenta ha sido desactivada. Contacta al administrador si crees que es un error.'});
                } else {
                    document.getElementById('msg').innerHTML = '<span style="color:red;font-weight:bold">Tu cuenta ha sido desactivada. Contacta al administrador si crees que es un error.</span>';
                }
            } else {
                document.getElementById('msg').innerHTML = t;
            }
        }
    }).catch(err=>{document.getElementById('msg').innerHTML = 'Error de red';});
}

// toggle register box
document.getElementById('showRegister').addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('registerBox').style.display = 'block';
    window.scrollTo(0, document.getElementById('registerBox').offsetTop);
});
document.getElementById('cancelRegister').addEventListener('click', function(){
    document.getElementById('registerBox').style.display = 'none';
});

// register submit
document.getElementById('registerForm').onsubmit = function(e){
    e.preventDefault();
    let f = new FormData(this);
    fetch('client_register_ajax.php', {method:'POST', body: f})
    .then(r=>r.text()).then(t=>{
        if(t.trim() === 'OK'){
            window.location.href = 'client_documentos.php';
        } else {
            document.getElementById('msgRegister').innerHTML = t;
        }
    }).catch(err=>{document.getElementById('msgRegister').innerHTML = 'Error de red';});
}
</script>
</body>
</html>
