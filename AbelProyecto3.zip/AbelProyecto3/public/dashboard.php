<?php
require_once __DIR__ . '/../includes/db.php';
session_start();

// Validar sesión: solo staff puede ver el dashboard
if(!isset($_SESSION['user_type']) || !isset($_SESSION['user_nombre'])){
    header('Location: login.php');
    exit;
}
if($_SESSION['user_type'] === 'cliente'){
    header('Location: client_documentos.php');
    exit;
}

$usuario = htmlspecialchars($_SESSION['user_nombre']);
?>

<?php require_once __DIR__ . '/../includes/header.php'; ?>

<!-- Hero Section -->
<div class="hero-section mb-5">
    <div class="hero-content">
        <div class="hero-greeting">
            <span class="hero-wave">👋</span>
            <span class="hero-welcome-text">Bienvenido de nuevo</span>
        </div>
        <h1 class="hero-username"><?php echo $usuario; ?></h1>
        <p class="hero-subtitle">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 6px;">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                <line x1="9" y1="3" x2="9" y2="21"/>
            </svg>
            Panel de control del sistema
        </p>
    </div>
    <div class="hero-decoration">
        <div class="hero-circle hero-circle-1"></div>
        <div class="hero-circle hero-circle-2"></div>
        <div class="hero-circle hero-circle-3"></div>
    </div>
</div>

<!-- Dashboard Cards Grid -->
<div class="row g-4">
    <!-- Clientes Card -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card dashboard-card h-100">
            <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <div class="dashboard-icon-wrapper icon-blue">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#155DFC" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                        </svg>
                    </div>
                </div>
                <h5 class="card-title mb-2 dashboard-card-title">Clientes</h5>
                <p class="text-muted mb-3 flex-grow-1 dashboard-card-text">Gestión completa de clientes registrados</p>
                <a class="btn btn-primary w-100 dashboard-btn" href="clientes.php">
                    Abrir módulo
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 6px; vertical-align: middle;">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Empleados Card -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card dashboard-card h-100">
            <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <div class="dashboard-icon-wrapper icon-purple">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <polyline points="16 11 18 13 22 9"></polyline>
                        </svg>
                    </div>
                </div>
                <h5 class="card-title mb-2 dashboard-card-title">Empleados</h5>
                <p class="text-muted mb-3 flex-grow-1 dashboard-card-text">Control y administración de personal</p>
                <a class="btn btn-primary w-100 dashboard-btn" href="empleados.php">
                    Abrir módulo
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 6px; vertical-align: middle;">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Documentos Card -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card dashboard-card h-100">
            <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <div class="dashboard-icon-wrapper icon-green">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                    </div>
                </div>
                <h5 class="card-title mb-2 dashboard-card-title">Documentos</h5>
                <p class="text-muted mb-3 flex-grow-1 dashboard-card-text">Subida y consulta de archivos</p>
                <a class="btn btn-primary w-100 dashboard-btn" href="documentos.php">
                    Abrir módulo
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 6px; vertical-align: middle;">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Pagos Card -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card dashboard-card h-100">
            <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <div class="dashboard-icon-wrapper icon-yellow">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                    </div>
                </div>
                <h5 class="card-title mb-2 dashboard-card-title">Pagos</h5>
                <p class="text-muted mb-3 flex-grow-1 dashboard-card-text">Comprobantes y control financiero</p>
                <a class="btn btn-primary w-100 dashboard-btn" href="pagos.php">
                    Abrir módulo
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 6px; vertical-align: middle;">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats Section -->
<div class="row g-4 mt-4">
    <div class="col-12">
        <div class="stats-card">
            <div class="card-body py-4">
                <div class="row text-center">
                    <div class="col-6 col-md-3 mb-3 mb-md-0">
                        <div class="stat-number">
                            <?php
                            $q = mysqli_query($conn, "SELECT COUNT(*) as total FROM clientes WHERE status=1");
                            $r = mysqli_fetch_assoc($q);
                            echo $r['total'] ?? 0;
                            ?>
                        </div>
                        <div class="stat-label">Clientes Activos</div>
                    </div>
                    <div class="col-6 col-md-3 mb-3 mb-md-0">
                        <div class="stat-number">
                            <?php
                            $has_status = false;
                            $col_check = mysqli_query($conn, "SHOW COLUMNS FROM empleados LIKE 'status'");
                            if($col_check && mysqli_num_rows($col_check) > 0) {
                                $has_status = true;
                            }
                            if($has_status) {
                                $q = mysqli_query($conn, "SELECT COUNT(*) as total FROM empleados WHERE status=1");
                            } else {
                                $q = mysqli_query($conn, "SELECT COUNT(*) as total FROM empleados");
                            }
                            $r = mysqli_fetch_assoc($q);
                            echo $r['total'] ?? 0;
                            ?>
                        </div>
                        <div class="stat-label">Empleados Activos</div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="stat-number">
                            <?php
                            $q = mysqli_query($conn, "SELECT COUNT(*) as total FROM documentos");
                            $r = mysqli_fetch_assoc($q);
                            echo $r['total'] ?? 0;
                            ?>
                        </div>
                        <div class="stat-label">Documentos</div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="stat-number">
                            <?php
                            $q = mysqli_query($conn, "SELECT COUNT(*) as total FROM pagos");
                            $r = mysqli_fetch_assoc($q);
                            echo $r['total'] ?? 0;
                            ?>
                        </div>
                        <div class="stat-label">Pagos Registrados</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Resumen Simple -->
<div class="row g-4 mt-4">
    <div class="col-12">
        <div class="card simple-summary">
            <div class="card-body">
                <h5 class="mb-3" style="font-weight: 600; color: var(--primary-blue);">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px; vertical-align: middle;">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                    Últimos Clientes Registrados
                </h5>
                <div class="summary-list">
                    <?php
                    // Verificar si existe la columna registrado_por_tipo
                    $has_tipo = false;
                    $col_check = mysqli_query($conn, "SHOW COLUMNS FROM clientes LIKE 'registrado_por_tipo'");
                    if($col_check && mysqli_num_rows($col_check) > 0) $has_tipo = true;
                    
                    $q = mysqli_query($conn, "SELECT nombre, fecha_registro, empleado_reg_id" . ($has_tipo ? ", registrado_por_tipo" : "") . " FROM clientes ORDER BY id DESC LIMIT 5");
                    if($q && mysqli_num_rows($q) > 0){
                        while($cliente = mysqli_fetch_assoc($q)){
                            $fecha = date('d/m/Y H:i', strtotime($cliente['fecha_registro']));
                            $empleado_id = (int)($cliente['empleado_reg_id'] ?? 0);
                            $tipo = $has_tipo ? ($cliente['registrado_por_tipo'] ?? '') : '';
                            
                            // Determinar quién registró
                            $registrado_por = 'Auto-registrado';
                            if($empleado_id > 0){
                                if($tipo === 'admin'){
                                    $r = mysqli_query($conn, "SELECT nombre FROM usuarios WHERE id=$empleado_id LIMIT 1");
                                    if($r && mysqli_num_rows($r)){
                                        $u = mysqli_fetch_assoc($r);
                                        $registrado_por = htmlspecialchars($u['nombre']) . ' (Admin)';
                                    }
                                } elseif($tipo === 'empleado'){
                                    // Buscar primero en usuarios
                                    $r = mysqli_query($conn, "SELECT nombre FROM usuarios WHERE id=$empleado_id AND rol_id=2 LIMIT 1");
                                    if($r && mysqli_num_rows($r)){
                                        $u = mysqli_fetch_assoc($r);
                                        $registrado_por = htmlspecialchars($u['nombre']) . ' (Empleado)';
                                    } else {
                                        // Buscar en empleados
                                        $r = mysqli_query($conn, "SELECT nombre FROM empleados WHERE id=$empleado_id LIMIT 1");
                                        if($r && mysqli_num_rows($r)){
                                            $e = mysqli_fetch_assoc($r);
                                            $registrado_por = htmlspecialchars($e['nombre']) . ' (Empleado)';
                                        }
                                    }
                                } else {
                                    // Sin tipo, buscar en usuarios primero
                                    $r = mysqli_query($conn, "SELECT nombre, rol_id FROM usuarios WHERE id=$empleado_id LIMIT 1");
                                    if($r && mysqli_num_rows($r)){
                                        $u = mysqli_fetch_assoc($r);
                                        $rol = ((int)$u['rol_id'] === 1) ? 'Admin' : 'Empleado';
                                        $registrado_por = htmlspecialchars($u['nombre']) . " ($rol)";
                                    } else {
                                        $r = mysqli_query($conn, "SELECT nombre FROM empleados WHERE id=$empleado_id LIMIT 1");
                                        if($r && mysqli_num_rows($r)){
                                            $e = mysqli_fetch_assoc($r);
                                            $registrado_por = htmlspecialchars($e['nombre']) . ' (Empleado)';
                                        }
                                    }
                                }
                            }
                            
                            echo '<div class="summary-list-item">';
                            echo '<div class="summary-item-left">';
                            echo '<div class="summary-avatar">';
                            echo '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">';
                            echo '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>';
                            echo '</svg>';
                            echo '</div>';
                            echo '<div class="summary-client-info">';
                            echo '<span class="summary-client-name">' . htmlspecialchars($cliente['nombre']) . '</span>';
                            echo '<small class="summary-registered-by">';
                            echo '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 4px;">';
                            echo '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>';
                            echo '</svg>';
                            echo 'Registrado por: ' . $registrado_por;
                            echo '</small>';
                            echo '</div>';
                            echo '</div>';
                            echo '<div class="summary-item-right">';
                            echo '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 4px;">';
                            echo '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>';
                            echo '</svg>';
                            echo '<small class="summary-date">' . $fecha . '</small>';
                            echo '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p class="text-muted text-center py-4 mb-0">No hay clientes registrados</p>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
