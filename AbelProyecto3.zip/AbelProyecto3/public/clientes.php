<?php
require_once __DIR__ . '/../includes/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Sólo el personal (administrador o empleado) puede gestionar clientes aquí. Los clientes editan su propio perfil en su área.
if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'staff'){
        header('Location: login.php');
        exit;
}
?>

<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="d-flex mb-4 align-items-center">
    <div>
        <h2 class="m-0" style="font-weight: 600; color: var(--primary-blue);">Gestión de Clientes</h2>
        <p class="text-muted mb-0 mt-1" style="font-size: 0.9375rem;">Administra y consulta la información de clientes</p>
    </div>
    <a class="btn btn-secondary ms-auto" href="dashboard.php">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem;">
            <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
        </svg>
        Volver
    </a>
</div>

<div class="row g-4">
    <div class="col-lg-5">
        <div class="card alta-bloque">
            <div class="card-body">
                <h3 class="card-title">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem; vertical-align: middle;">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>
                    </svg>
                    Registrar cliente
                </h3>
                <form id="formAdd">
                    <div class="mb-2">
                        <label class="form-label">Nombre</label>
                        <input class="form-control" type="text" name="nombre" placeholder="Nombre" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Teléfono</label>
                        <input class="form-control" type="text" name="telefono" placeholder="Teléfono">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Email</label>
                        <input class="form-control" type="email" name="email" placeholder="email@dominio.com">
                    </div>
                    <div class="mb-2">
                        <?php if(isset($_SESSION['rol_id']) && (int)$_SESSION['rol_id'] === 1): ?>
                        <label class="form-label">Contraseña</label>
                        <input class="form-control" type="password" name="password" placeholder="Contraseña">
                        <?php endif; ?>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Dirección</label>
                        <textarea class="form-control" name="direccion"></textarea>
                    </div>
                    <div class="d-grid">
                        <button class="btn btn-primary">Guardar</button>
                    </div>
                </form>
                <div id="msg" class="mt-3"></div>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card consulta-bloque">
            <div class="card-body">
                        <div class="d-flex mb-3 align-items-center">
                            <h3 class="card-title m-0">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem; vertical-align: middle;">
                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
                                </svg>
                                Clientes registrados
                            </h3>
                            <div class="ms-auto d-flex align-items-center gap-2">
                                <div class="mostrar-inactivos-toggle">
                                    <svg width="18" height="18" fill="none" viewBox="0 0 24 24" class="mostrar-inactivos-icon">
                                        <circle id="iconCircleClientes" cx="12" cy="12" r="10" fill="#ef4444"/>
                                    </svg>
                                    <label class="form-label mb-0 mostrar-inactivos-label" for="toggleInactivos" style="cursor: pointer;">Mostrar inactivos</label>
                                    <input class="form-check-input" type="checkbox" id="toggleInactivos" style="cursor: pointer;">
                                </div>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function(){
                                        const toggleC = document.getElementById('toggleInactivos');
                                        const iconC = document.getElementById('iconCircleClientes');
                                        function update(){
                                            if(toggleC && iconC){
                                                iconC.setAttribute('fill', toggleC.checked ? '#10b981' : '#ef4444');
                                            }
                                        }
                                        update();
                                        if(toggleC) toggleC.addEventListener('change', update);
                                    });
                                </script>
                            </div>
                        </div>
                        <div id="listaClientes">Cargando...</div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
function cargarClientes(){
    let form = new FormData();
    form.append('accion','listar');
    // enviar flag para mostrar inactivos cuando esté activo el checkbox
    const showInactivos = document.getElementById('toggleInactivos') && document.getElementById('toggleInactivos').checked;
    if(showInactivos) form.append('inactivos','1');
        enviarAjax('clientes_ajax.php', form, function(resp){
        // replace content
        document.getElementById('listaClientes').innerHTML = resp;
        // inicializar DataTable con configuración mejorada
        if(window.jQuery && $.fn.dataTable){
            if($.fn.dataTable.isDataTable('.datatable')){
                try{ $('.datatable').DataTable().destroy(); }catch(e){ }
            }
            $('.datatable').DataTable({
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                     '<"row"<"col-sm-12"B>>' +
                     '<"row"<"col-sm-12"tr>>' +
                     '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                buttons: [
                    { extend: 'copy', text: 'Copiar', className: 'buttons-copy' },
                    { extend: 'excel', text: 'Excel', className: 'buttons-excel', title: 'SALUD-FILE - Clientes' },
                    { 
                        extend: 'pdf', 
                        text: 'PDF', 
                        className: 'buttons-pdf',
                        title: 'SALUD-FILE - Clientes',
                        orientation: 'landscape',
                        pageSize: 'A4',
                        exportOptions: {
                            columns: ':visible',
                            stripHtml: true
                        },
                        customize: function(doc) {
                            doc.pageMargins = [40, 100, 40, 50];
                            
                            // Header minimalista y elegante
                            doc.header = function(currentPage, pageCount) {
                                return {
                                    margin: [40, 25, 40, 0],
                                    columns: [
                                        {
                                            width: 'auto',
                                            text: 'SaludFile',
                                            fontSize: 20,
                                            bold: true,
                                            color: '#155DFC'
                                        },
                                        {
                                            width: '*',
                                            text: 'Clientes',
                                            fontSize: 20,
                                            color: '#64748b',
                                            alignment: 'left',
                                            margin: [8, 0, 0, 0]
                                        }
                                    ]
                                };
                            };
                            
                            // Footer minimalista
                            doc.footer = function(currentPage, pageCount) {
                                return {
                                    margin: [40, 15, 40, 0],
                                    columns: [
                                        { 
                                            text: new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' }), 
                                            fontSize: 8, 
                                            color: '#94a3b8' 
                                        },
                                        { 
                                            text: currentPage + ' / ' + pageCount, 
                                            alignment: 'right', 
                                            fontSize: 8, 
                                            color: '#94a3b8' 
                                        }
                                    ]
                                };
                            };
                            
                            // Estilos de tabla minimalistas
                            doc.defaultStyle = {
                                fontSize: 9
                            };
                            
                            doc.styles.tableHeader = {
                                fontSize: 9,
                                bold: true,
                                fillColor: '#f8fafc',
                                color: '#1e293b',
                                alignment: 'left'
                            };
                            
                            // Configuración de tabla
                            if(doc.content[0] && doc.content[0].table) {
                                var table = doc.content[0].table;
                                table.widths = Array(table.body[0].length).fill('auto');
                                table.layout = {
                                    hLineWidth: function(i, node) { 
                                        return (i === 1) ? 1.5 : 0.5;
                                    },
                                    vLineWidth: function(i) { return 0; },
                                    hLineColor: function(i, node) { 
                                        return (i === 1) ? '#155DFC' : '#e2e8f0';
                                    },
                                    fillColor: function(i) { 
                                        return (i === 0) ? '#f8fafc' : (i % 2 === 0) ? '#fafbfc' : null;
                                    },
                                    paddingLeft: function(i) { return i === 0 ? 0 : 8; },
                                    paddingRight: function(i, node) { return (i === node.table.widths.length - 1) ? 0 : 8; },
                                    paddingTop: function() { return 8; },
                                    paddingBottom: function() { return 8; }
                                };
                            }
                        }
                    },
                    { extend: 'print', text: 'Imprimir', className: 'buttons-print', title: 'SALUD-FILE - Clientes' }
                ],
                responsive: {
                    details: {
                        type: 'column',
                        target: 'tr'
                    }
                },
                columnDefs: [
                    { responsivePriority: 1, targets: 0 },  // ID
                    { responsivePriority: 2, targets: 1 },  // Nombre
                    { responsivePriority: 3, targets: -1 }, // Acciones (última columna)
                    { responsivePriority: 10000, targets: '_all' } // Resto de columnas
                ],
                pageLength: 10,
                lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
                language: { 
                    url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
                    buttons: {
                        copy: 'Copiar',
                        copyTitle: 'Copiado',
                        copySuccess: { _: '%d filas copiadas', 1: '1 fila copiada' }
                    }
                },
                order: [[0, 'desc']]
            });
        }
        });
}
cargarClientes();
// recargar al cambiar el checkbox
$('#toggleInactivos').on('change', function(){ cargarClientes(); });

$('#formAdd').on('submit', function(e){
        e.preventDefault();
        let form = new FormData(this);
        form.append('accion','agregar');
        enviarAjax('clientes_ajax.php', form, function(resp){
                let lower = (resp||'').toLowerCase();
                if(lower.includes('ya existe') || lower.includes('correo inválido') || lower.includes('error:')){
                    Swal.fire({icon:'error', title:'Error', text: resp});
                } else {
                    Swal.fire({icon:'success', title:'Hecho', text: resp});
                    document.getElementById('formAdd').reset();
                    cargarClientes();
                }
        });
});

function eliminarCliente(id){
        Swal.fire({
            title: 'Confirmar', text: '¿Dar de baja este cliente?', icon: 'warning', showCancelButton:true
        }).then((result)=>{
            if(result.isConfirmed){
                let form = new FormData(); form.append('accion','eliminar'); form.append('id',id);
                enviarAjax('clientes_ajax.php', form, function(resp){
                    let lower = (resp||'').toLowerCase();
                    if(lower.includes('error') || lower.includes('id inválido') || lower.includes('no autorizado')){
                        Swal.fire({icon:'error', title:'Error', text: resp});
                    } else {
                        Swal.fire({icon:'success', title:'Hecho', text: resp});
                    }
                    cargarClientes();
                });
            }
        });
}

function activarCliente(id){
        Swal.fire({
            title: 'Confirmar', text: '¿Reactivar este cliente?', icon: 'question', showCancelButton:true
        }).then((result)=>{
            if(result.isConfirmed){
                let form = new FormData(); form.append('accion','activar'); form.append('id',id);
                enviarAjax('clientes_ajax.php', form, function(resp){
                    let lower = (resp||'').toLowerCase();
                    if(lower.includes('error') || lower.includes('id inválido') || lower.includes('no autorizado')){
                        Swal.fire({icon:'error', title:'Error', text: resp});
                    } else {
                        Swal.fire({icon:'success', title:'Hecho', text: resp});
                    }
                    cargarClientes();
                });
            }
        });
}

function verEditar(id){
        let form = new FormData(); form.append('accion','ver'); form.append('id', id);
        enviarAjax('clientes_ajax.php', form, function(resp){ document.getElementById('msg').innerHTML = resp; });
}

function guardarEdicion(id){
        let nombre = document.getElementById('edit_nombre').value;
        let telefono = document.getElementById('edit_telefono').value;
        let direccion = document.getElementById('edit_direccion').value;
    let email = document.getElementById('edit_email') ? document.getElementById('edit_email').value : '';
    let password = document.getElementById('edit_password') ? document.getElementById('edit_password').value : '';
    let form = new FormData(); form.append('accion','editar'); form.append('id',id);
    form.append('nombre',nombre); form.append('telefono',telefono); form.append('direccion',direccion); form.append('email', email);
    if(password) form.append('password', password);
    enviarAjax('clientes_ajax.php', form, function(resp){ Swal.fire({icon:'success', text:resp}); cargarClientes(); document.getElementById('msg').innerHTML=''; });
}
</script>
