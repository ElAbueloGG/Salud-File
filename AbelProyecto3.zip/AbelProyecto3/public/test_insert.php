<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

echo "<h1>Test de Inserción de Cliente</h1>";

// Mostrar estructura de la tabla
echo "<h2>Estructura de tabla clientes:</h2>";
$q = mysqli_query($conn, "SHOW COLUMNS FROM clientes");
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
while($col = mysqli_fetch_assoc($q)){
    echo "<tr>";
    echo "<td>{$col['Field']}</td>";
    echo "<td>{$col['Type']}</td>";
    echo "<td>{$col['Null']}</td>";
    echo "<td>{$col['Key']}</td>";
    echo "<td>{$col['Default']}</td>";
    echo "</tr>";
}
echo "</table>";

// Mostrar datos de sesión
echo "<h2>Datos de Sesión:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

// Test de email único
echo "<h2>Test de Email Único:</h2>";
$test_email = "test@example.com";
$esc_test = mysqli_real_escape_string($conn, $test_email);
$check = mysqli_query($conn, "SELECT id, nombre, email FROM clientes WHERE email='$esc_test' LIMIT 1");
echo "Buscando: $test_email<br>";
echo "Resultados: " . mysqli_num_rows($check) . "<br>";
if(mysqli_num_rows($check) > 0){
    $existing = mysqli_fetch_assoc($check);
    echo "Cliente existente: <pre>";
    print_r($existing);
    echo "</pre>";
}

// Mostrar últimos 5 clientes
echo "<h2>Últimos 5 Clientes:</h2>";
$q = mysqli_query($conn, "SELECT id, nombre, email, empleado_reg_id, registrado_por_tipo, fecha_registro FROM clientes ORDER BY id DESC LIMIT 5");
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Nombre</th><th>Email</th><th>Empleado Reg ID</th><th>Tipo</th><th>Fecha</th></tr>";
while($c = mysqli_fetch_assoc($q)){
    echo "<tr>";
    echo "<td>{$c['id']}</td>";
    echo "<td>{$c['nombre']}</td>";
    echo "<td>{$c['email']}</td>";
    echo "<td>{$c['empleado_reg_id']}</td>";
    echo "<td>" . ($c['registrado_por_tipo'] ?? 'NULL') . "</td>";
    echo "<td>{$c['fecha_registro']}</td>";
    echo "</tr>";
}
echo "</table>";

echo "<p><a href='clientes.php'>Volver a Clientes</a></p>";
?>
