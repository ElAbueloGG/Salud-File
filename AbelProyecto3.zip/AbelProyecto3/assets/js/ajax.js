function enviarAjax(url, form, callback){
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    // tiempo de espera en ms
    xhr.timeout = 30000;

    xhr.onload = function(){
        if(xhr.status == 200){
            callback(xhr.responseText);
        } else {
            callback(xhr.responseText || "ERROR_HTTP");
        }
    };

    xhr.onerror = function(){
        callback("ERROR_NETWORK");
    };

    xhr.ontimeout = function(){
        callback("ERROR_TIMEOUT");
    };

    xhr.send(form);
}
