<?php
// Cabecera común: incluye Bootstrap5, DataTables, SweetAlert2
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sistema</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css" rel="stylesheet">
  <link href="/sistema/assets/css/custom.css" rel="stylesheet">
  <!-- Google Fonts: Inter for UI and Playfair Display for title -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="/sistema/assets/js/ajax.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-modern">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center gap-2" href="/sistema/public/dashboard.php" aria-label="Ir al inicio">
      <div class="logo-wrapper">
        <img src="/sistema/assets/images/logo.png" alt="Inicio" class="navbar-logo">
      </div>
      <span class="brand-text d-none d-lg-inline">SALUD-FILE</span>
    </a>
    <button id="navbarTogglerBtn" class="navbar-toggler" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon-custom">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        </svg>
      </span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center gap-2">
        <?php if(session_status() === PHP_SESSION_NONE) session_start(); ?>
        <?php if(isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'staff'): ?>
          <li class="nav-item"><a class="nav-link-modern" href="/sistema/public/clientes.php">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            Clientes
          </a></li>
          <li class="nav-item"><a class="nav-link-modern" href="/sistema/public/documentos.php">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            Documentos
          </a></li>
          <li class="nav-item"><a class="nav-link-modern" href="/sistema/public/pagos.php">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            Pagos
          </a></li>
        <?php elseif(isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'cliente'): ?>
          <li class="nav-item"><a class="nav-link-modern" href="/sistema/public/client_documentos.php">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            Mis Documentos
          </a></li>
        <?php endif; ?>
        <?php if(isset($_SESSION['user_nombre'])): ?>
          <li class="nav-item">
            <a class="profile-btn" href="/sistema/public/profile.php" title="<?php echo htmlspecialchars($_SESSION['user_nombre']); ?>">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </a>
          </li>
          <li class="nav-item">
            <a class="logout-btn" href="/sistema/public/logout.php" title="Cerrar sesión">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
            </a>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link-modern" href="/sistema/public/login.php">Iniciar sesión</a></li>
        <?php endif; ?>
        <li class="nav-item">
          <button id="darkModeBtn" class="theme-toggle-btn" title="Cambiar tema" aria-label="Cambiar tema">
            <svg id="iconSol" width="20" height="20" viewBox="0 0 24 24" fill="none" style="display:none;">
              <circle cx="12" cy="12" r="5" fill="currentColor"/>
              <line x1="12" y1="1" x2="12" y2="3" stroke="currentColor" stroke-width="2"/>
              <line x1="12" y1="21" x2="12" y2="23" stroke="currentColor" stroke-width="2"/>
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" stroke="currentColor" stroke-width="2"/>
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" stroke="currentColor" stroke-width="2"/>
              <line x1="1" y1="12" x2="3" y2="12" stroke="currentColor" stroke-width="2"/>
              <line x1="21" y1="12" x2="23" y2="12" stroke="currentColor" stroke-width="2"/>
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" stroke="currentColor" stroke-width="2"/>
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" stroke="currentColor" stroke-width="2"/>
            </svg>
            <svg id="iconLuna" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="display:block;">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
          </button>
        </li>
      </ul>
    </div>
  </div>
</nav>

<main class="container-fluid my-4">

<script>
  document.addEventListener('DOMContentLoaded', function() {
    const darkModeBtn = document.getElementById('darkModeBtn');
    const iconSol = document.getElementById('iconSol');
    const iconLuna = document.getElementById('iconLuna');
    function setDarkMode(active) {
      const body = document.body;
      if(active){
        body.classList.add('dark-mode');
        iconSol.style.display = 'block';
        iconLuna.style.display = 'none';
        localStorage.setItem('sistemaDarkMode', '1');
      }else{
        body.classList.remove('dark-mode');
        iconSol.style.display = 'none';
        iconLuna.style.display = 'block';
        localStorage.setItem('sistemaDarkMode', '0');
      }
    }
    let darkMode = localStorage.getItem('sistemaDarkMode') === '1';
    setDarkMode(darkMode);
    darkModeBtn.addEventListener('click', function(){
      darkMode = !darkMode;
      setDarkMode(darkMode);
      
      // Refrescar DataTables si existen para aplicar estilos de modo oscuro
      if(window.jQuery && $.fn.DataTable){
        $('.datatable').each(function(){
          if($.fn.dataTable.isDataTable(this)){
            try {
              $(this).DataTable().draw(false);
            } catch(e) {
              console.log('DataTable refresh skipped');
            }
          }
        });
      }
    });
    // Ajuste: manejar estado visual del navbar-toggler (open cuando el collapse está visible)
    const navbarToggler = document.querySelector('.navbar .navbar-toggler');
    const navbarCollapse = document.getElementById('navbarSupportedContent');
    if(navbarCollapse && navbarToggler){
      // Create a Bootstrap Collapse instance without auto-toggle so we control it programmatically
      let bsCollapse = null;
      try{
        bsCollapse = new bootstrap.Collapse(navbarCollapse, { toggle: false });
      }catch(e){
        // bootstrap may not be available yet; ignore
      }
      // Sync with final shown/hidden events to avoid stuck state
      navbarCollapse.addEventListener('shown.bs.collapse', function(){
        navbarToggler.classList.add('open');
      });
      navbarCollapse.addEventListener('hidden.bs.collapse', function(){
        navbarToggler.classList.remove('open');
      });
      // Use programmatic toggle on the button to avoid conflicts with data attributes
      const navbarTogglerBtn = document.getElementById('navbarTogglerBtn');
      if(navbarTogglerBtn){
        navbarTogglerBtn.addEventListener('click', function(evt){
          evt.preventDefault();
          evt.stopPropagation();
          if(bsCollapse){
            bsCollapse.toggle();
          }else{
            // fallback: toggle class directly (no animation)
            if(navbarCollapse.classList.contains('show')){
              navbarCollapse.classList.remove('show');
              navbarToggler.classList.remove('open');
            }else{
              navbarCollapse.classList.add('show');
              navbarToggler.classList.add('open');
            }
          }
        });
      }
      // Ensure correct initial state in case collapse is pre-open
      if(navbarCollapse.classList.contains('show')){
        navbarToggler.classList.add('open');
      }
    }
  });
</script>
