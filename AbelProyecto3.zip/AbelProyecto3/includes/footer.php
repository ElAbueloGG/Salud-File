<?php
// Pie común: incluye scripts de Bootstrap
?>

</main>

<footer class="footer-modern py-4 mt-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
        <div class="d-flex align-items-center justify-content-center justify-content-md-start gap-2">
          <img src="/sistema/assets/images/logo.png" alt="SALUD-FILE" style="height: 32px; width: 32px; border-radius: 8px;">
          <span class="footer-brand">SALUD-FILE</span>
        </div>
      </div>
      <div class="col-md-6 text-center text-md-end">
        <small class="footer-text">&copy; <?php echo date('Y'); ?> SALUD-FILE. Sistema de gestión médica.</small>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Helper para mostrar alertas usando SweetAlert2
function alerta(tipo, titulo, texto){
  Swal.fire({
    icon: tipo,
    title: titulo,
    text: texto,
    confirmButtonColor: '#155DFC',
    customClass: {
      popup: 'swal-modern',
      confirmButton: 'btn-modern'
    }
  });
}

// Inicializador mejorado para tablas con clase .datatable
$(document).ready(function(){
  if($.fn.DataTable){
    $('.datatable').each(function(){
      // Inicializar solo si no está ya inicializada
      if(!$.fn.dataTable.isDataTable(this)){
        $(this).DataTable({
          dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
               '<"row"<"col-sm-12"B>>' +
               '<"row"<"col-sm-12"tr>>' +
               '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
          buttons: [
            {
              extend: 'copy',
              text: 'Copiar',
              className: 'buttons-copy',
              exportOptions: {
                columns: ':visible'
              }
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'buttons-excel',
              title: 'SALUD-FILE - Exportación',
              exportOptions: {
                columns: ':visible'
              }
            },
            {
              extend: 'pdf',
              text: 'PDF',
              className: 'buttons-pdf',
              title: 'SALUD-FILE - Exportación',
              orientation: 'landscape',
              pageSize: 'A4',
              exportOptions: {
                columns: ':visible',
                stripHtml: true
              },
              customize: function(doc) {
                // Configuración de página
                doc.pageMargins = [40, 120, 40, 60];
                
                // Encabezado personalizado con logo y título
                doc.header = function(currentPage, pageCount) {
                  return {
                    columns: [
                      {
                        width: '*',
                        stack: [
                          {
                            text: 'SALUD-FILE',
                            style: 'header',
                            fontSize: 24,
                            bold: true,
                            color: '#155DFC',
                            margin: [40, 20, 0, 5]
                          },
                          {
                            text: 'Sistema de Gestión Médica',
                            fontSize: 12,
                            color: '#64748b',
                            margin: [40, 0, 0, 0]
                          },
                          {
                            canvas: [
                              {
                                type: 'line',
                                x1: 40, y1: 10,
                                x2: 555, y2: 10,
                                lineWidth: 2,
                                lineColor: '#155DFC'
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  };
                };
                
                // Pie de página con número de página
                doc.footer = function(currentPage, pageCount) {
                  return {
                    columns: [
                      {
                        text: 'Fecha: ' + new Date().toLocaleDateString('es-ES', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        }) + ' - ' + new Date().toLocaleTimeString('es-ES'),
                        fontSize: 9,
                        color: '#64748b',
                        margin: [40, 10, 0, 0]
                      },
                      {
                        text: 'Página ' + currentPage.toString() + ' de ' + pageCount,
                        alignment: 'right',
                        fontSize: 9,
                        color: '#64748b',
                        margin: [0, 10, 40, 0]
                      }
                    ]
                  };
                };
                
                // Estilos del documento
                doc.defaultStyle = {
                  fontSize: 9,
                  font: 'Roboto'
                };
                
                // Estilos de la tabla
                doc.styles.tableHeader = {
                  fontSize: 10,
                  bold: true,
                  fillColor: '#155DFC',
                  color: '#ffffff',
                  alignment: 'center'
                };
                
                // Configuración de la tabla
                if(doc.content[0] && doc.content[0].table) {
                  var table = doc.content[0].table;
                  
                  // Ancho automático de columnas
                  table.widths = Array(table.body[0].length).fill('auto');
                  
                  // Layout mejorado
                  table.layout = {
                    hLineWidth: function(i, node) {
                      if (i === 0 || i === 1) return 2;
                      if (i === node.table.body.length) return 2;
                      return 0.5;
                    },
                    vLineWidth: function(i, node) {
                      return 0.5;
                    },
                    hLineColor: function(i, node) {
                      if (i === 0 || i === 1 || i === node.table.body.length) return '#155DFC';
                      return '#e2e8f0';
                    },
                    vLineColor: function(i, node) {
                      return '#e2e8f0';
                    },
                    fillColor: function(rowIndex, node, columnIndex) {
                      if (rowIndex === 0) return '#155DFC';
                      return (rowIndex % 2 === 0) ? '#f8fafc' : null;
                    },
                    paddingLeft: function(i, node) { return 8; },
                    paddingRight: function(i, node) { return 8; },
                    paddingTop: function(i, node) { return 6; },
                    paddingBottom: function(i, node) { return 6; }
                  };
                  
                  // Estilo de celdas
                  for (var i = 1; i < table.body.length; i++) {
                    for (var j = 0; j < table.body[i].length; j++) {
                      table.body[i][j].alignment = 'left';
                      table.body[i][j].fontSize = 9;
                    }
                  }
                }
              }
            },
            {
              extend: 'print',
              text: 'Imprimir',
              className: 'buttons-print',
              title: 'SALUD-FILE - Impresión',
              exportOptions: {
                columns: ':visible'
              },
              customize: function(win) {
                // Personalizar la ventana de impresión
                $(win.document.body)
                  .css('font-family', 'Inter, Arial, sans-serif')
                  .css('font-size', '10pt');
                
                $(win.document.body).find('table')
                  .addClass('compact')
                  .css('font-size', '10pt')
                  .css('border-collapse', 'collapse')
                  .css('width', '100%');
                
                $(win.document.body).find('table thead')
                  .css('background-color', '#155DFC')
                  .css('color', '#ffffff');
                
                $(win.document.body).find('table th, table td')
                  .css('border', '1px solid #e2e8f0')
                  .css('padding', '8px');
                
                // Agregar encabezado personalizado
                $(win.document.body).prepend(
                  '<div style="text-align: center; margin-bottom: 20px;">' +
                  '<h1 style="color: #155DFC; margin-bottom: 5px;">SALUD-FILE</h1>' +
                  '<p style="color: #64748b; font-size: 12pt;">Sistema de Gestión Médica</p>' +
                  '<p style="color: #94a3b8; font-size: 10pt;">Fecha: ' + new Date().toLocaleDateString('es-ES') + '</p>' +
                  '</div>'
                );
              }
            }
          ],
          responsive: true,
          language: {
            url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
            buttons: {
              copy: 'Copiar',
              copyTitle: 'Copiado al portapapeles',
              copySuccess: {
                _: '%d filas copiadas',
                1: '1 fila copiada'
              }
            }
          },
          pageLength: 25,
          lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Todos"]],
          order: [[0, 'desc']]
        });
      }
    });
  }
});
</script>
</body>
</html>
