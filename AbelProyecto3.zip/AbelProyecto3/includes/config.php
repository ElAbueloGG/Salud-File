<?php
// CONFIGURACIÓN GENERAL DEL SISTEMA
// ----------------------------------

// Nombre del sistema
$APP_NAME = "SALUD-FILE";

// Carpeta donde se guardan los archivos subidos
$UPLOADS_DIR = __DIR__ . "/../uploads/";

// Extensiones permitidas para documentos
$ALLOWED_DOCS = ["pdf","jpg","jpeg","png"];

// Extensiones permitidas para comprobantes
$ALLOWED_PAGOS = ["jpg","jpeg","png","pdf"];

// ----------------------------------
// CONEXIÓN A LA BASE DE DATOS
// ----------------------------------

$host = "localhost";
$user = "root";
$pass = "";
$db   = "sistema";  // <- Cambia esto si tu base se llama diferente

$conn = new mysqli($host, $user, $pass, $db);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
