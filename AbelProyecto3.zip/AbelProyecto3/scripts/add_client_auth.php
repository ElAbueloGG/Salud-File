<?php
// Script to add `email` and `password` columns to `clientes` table.
// CAUTION: Run in a safe environment and backup DB first.
// Usage: php add_client_auth.php run  OR visit via browser with ?run=1

require __DIR__ . '/../includes/db.php';

echo "Preview of clientes table columns:\n";
$res = mysqli_query($conn, "SHOW COLUMNS FROM clientes");
$cols = [];
while($c = mysqli_fetch_assoc($res)){
    $cols[] = $c['Field'];
}
print_r($cols);

if(in_array('email', $cols) || in_array('password', $cols)){
    echo "\nColumns already exist. No action needed.\n";
    exit;
}

$run = (isset($argv) && isset($argv[1]) && $argv[1] === 'run') || (isset($_GET['run']) && $_GET['run']==1);
if(!$run){
    echo "\nTo apply, run: php add_client_auth.php run  (or visit ?run=1)\n";
    exit;
}

$sqls = [
    "ALTER TABLE clientes ADD COLUMN email VARCHAR(100) DEFAULT NULL",
    "ALTER TABLE clientes ADD COLUMN password VARCHAR(255) DEFAULT NULL"
];

foreach($sqls as $sql){
    if(mysqli_query($conn, $sql)){
        echo "Executed: $sql\n";
    } else {
        echo "Error executing $sql : " . mysqli_error($conn) . "\n";
    }
}

echo "Done. Remember to set a password (hashed) for client accounts.\n";
